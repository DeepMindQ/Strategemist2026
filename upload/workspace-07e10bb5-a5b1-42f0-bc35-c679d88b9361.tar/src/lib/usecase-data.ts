/**
 * KefiTech CIP — Contextual Intelligence Platform
 * Industry use-case dataset.
 *
 * NOTE: This file describes SERVICE APPLICATIONS of contextual-intelligence /
 * graph-neural-network technology. It does NOT disclose any patent claims.
 * All capability names below are product/service framing, not claim language.
 */

export type CapabilityKey =
  | "dynamic-graph"
  | "anomaly-detection"
  | "multi-modal"
  | "hypergraph"
  | "quantum-embedding"
  | "streaming"
  | "generative"
  | "rl-optimization"
  | "topology"
  | "spectral"
  | "neuro-symbolic"
  | "compression";

export interface Capability {
  key: CapabilityKey;
  name: string;
  short: string;
  description: string;
}

export const CAPABILITIES: Capability[] = [
  {
    key: "dynamic-graph",
    name: "Dynamic Graph Engine",
    short: "DGE",
    description:
      "Continuously rewires nodes and edges as relationships evolve, preserving structural integrity across temporal snapshots.",
  },
  {
    key: "anomaly-detection",
    name: "Probabilistic Anomaly Detection",
    short: "PAD",
    description:
      "Models likelihood distributions over embeddings to flag deviations with statistical confidence in real time.",
  },
  {
    key: "multi-modal",
    name: "Multi-Modal Fusion",
    short: "MMF",
    description:
      "Unifies numerical signals, text and temporal streams into a single graph representation via attention-based alignment.",
  },
  {
    key: "hypergraph",
    name: "Hypergraph Modeling",
    short: "HGM",
    description:
      "Models multi-entity interactions beyond pairwise edges using tensor-encoded hyperedges for complex relational data.",
  },
  {
    key: "quantum-embedding",
    name: "Quantum-Inspired Embedding",
    short: "QIE",
    description:
      "Maps graph components into high-dimensional Hilbert-style spaces for parallel substructure processing.",
  },
  {
    key: "streaming",
    name: "Deterministic Streaming",
    short: "DST",
    description:
      "Micro-batched, conflict-resolved ingestion that updates the live graph without disrupting ongoing computation.",
  },
  {
    key: "generative",
    name: "Generative Reconstruction",
    short: "GRE",
    description:
      "Reconstructs missing or corrupted graph elements with adversarially-trained autoencoder models.",
  },
  {
    key: "rl-optimization",
    name: "RL Graph Optimization",
    short: "RLO",
    description:
      "Reward-driven refinement of edge weights, embeddings and topology for task-specific objectives.",
  },
  {
    key: "topology",
    name: "Topological Analytics",
    short: "TPA",
    description:
      "Captures topological invariants — loops, voids, cavities — to preserve structural patterns across resolutions.",
  },
  {
    key: "spectral",
    name: "Spectral Decomposition",
    short: "SPD",
    description:
      "Isolates task-relevant spectral bands via eigen-analysis of the graph Laplacian for precision clustering.",
  },
  {
    key: "neuro-symbolic",
    name: "Neuro-Symbolic Reasoning",
    short: "NSR",
    description:
      "Couples neural embeddings with symbolic inference rules for interpretable, domain-adaptable contextual reasoning.",
  },
  {
    key: "compression",
    name: "Fractal Compression",
    short: "FRC",
    description:
      "Encodes repetitive graph patterns as fractals to reduce memory footprint while preserving structural fidelity.",
  },
];

export interface UseCase {
  id: string;
  title: string;
  industry: string;
  subIndustry: string;
  summary: string;
  capabilities: CapabilityKey[];
  /** Implementation surface areas — concrete places the service plugs in. */
  surfaces: string[];
  /** Sample KPIs the service moves. */
  kpis: { label: string; delta: string; direction: "up" | "down" }[];
  /** Data sources the use case fuses. */
  dataSources: string[];
  /** Difficulty / maturity badge. */
  maturity: "Pilot" | "Deployed" | "Production" | "R&D";
  tags: string[];
}

export interface SubIndustry {
  id: string;
  name: string;
  description: string;
  useCases: UseCase[];
}

export interface Industry {
  id: string;
  name: string;
  code: string; // 3-letter code e.g. BNK
  tagline: string;
  description: string;
  accent: string; // hex
  icon: string; // lucide icon name
  metrics: { label: string; value: string; sub: string }[];
  subIndustries: SubIndustry[];
}

/* =========================================================================
   BANKING
   ========================================================================= */
const BANKING: Industry = {
  id: "banking",
  name: "Banking",
  code: "BNK",
  tagline: "Real-time relationship intelligence for money in motion.",
  description:
    "Banks operate on dense webs of accounts, counterparties, instruments and channels. CIP fuses these into a single living graph — exposing hidden rings, latent communities and emerging risks before they hit the ledger.",
  accent: "#004c97",
  icon: "Landmark",
  metrics: [
    { label: "Txn Graph Nodes", value: "1.4B", sub: "live accounts + counterparties" },
    { label: "Anomaly Latency", value: "42ms", sub: "p99 streaming detection" },
    { label: "False-Positive Cut", value: "−68%", sub: "vs rules engine baseline" },
    { label: "KYC Re-work", value: "−41%", sub: "entity resolution uplift" },
  ],
  subIndustries: [
    {
      id: "retail-banking",
      name: "Retail Banking",
      description: "Branch, digital and wallet channels for individual customers.",
      useCases: [
        {
          id: "bnk-rb-01",
          title: "Account-Takeover Ring Detection",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Fuses device fingerprints, session telemetry and beneficiary graphs to surface coordinated takeover rings operating across thousands of dormant accounts.",
          capabilities: ["dynamic-graph", "anomaly-detection", "streaming", "topology"],
          surfaces: ["Login telemetry", "Beneficiary master", "Card-token vault", "CRM events", "SIM-swap alerts"],
          kpis: [
            { label: "ATO loss", delta: "−54%", direction: "down" },
            { label: "Ring size detected", delta: "+312", direction: "up" },
            { label: "Mean time to detect", delta: "−72%", direction: "down" },
          ],
          dataSources: ["Device graph", "Session logs", "Beneficiary DB", "Telecom signals"],
          maturity: "Production",
          tags: ["fraud", "account-takeover", "device-graph", "real-time"],
        },
        {
          id: "bnk-rb-02",
          title: "Next-Best-Product on Relationship Graph",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Recommends products by traversing household, employment and life-event edges — not isolated transaction history — yielding higher acceptance and lower attrition.",
          capabilities: ["dynamic-graph", "rl-optimization", "neuro-symbolic", "multi-modal"],
          surfaces: ["Mobile app", "Branch CRM", "Campaign manager", "Offer engine"],
          kpis: [
            { label: "Offer acceptance", delta: "+34%", direction: "up" },
            { label: "CAC", delta: "−21%", direction: "down" },
            { label: "Cross-sell depth", delta: "+1.8", direction: "up" },
          ],
          dataSources: ["Household graph", "Payroll", "Credit bureau", "Life-event stream"],
          maturity: "Deployed",
          tags: ["recommendation", "cross-sell", "household", "rl"],
        },
        {
          id: "bnk-rb-03",
          title: "Churn Prediction on Community Embedding",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Embeds customers in their social and transactional community; churn risk rises when a customer's neighborhood thins — detected weeks before balance decline.",
          capabilities: ["spectral", "topology", "anomaly-detection"],
          surfaces: ["Retention ops", "Branch playbook", "Loyalty engine"],
          kpis: [
            { label: "Early-warning lead time", delta: "+21d", direction: "up" },
            { label: "Churn", delta: "−17%", direction: "down" },
          ],
          dataSources: ["P2P transfers", "Shared-merchant graph", "App social graph"],
          maturity: "Deployed",
          tags: ["churn", "embedding", "retention", "community"],
        },
        {
          id: "bnk-rb-04",
          title: "Branch + Digital Channel Convergence",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Stitches branch visits, ATM, IVR, mobile and web into one customer journey graph so hand-offs stop leaking context.",
          capabilities: ["multi-modal", "streaming", "dynamic-graph"],
          surfaces: ["Omnichannel orchestration", "Agent desktop", "Journey analytics"],
          kpis: [
            { label: "Repeat-call rate", delta: "−28%", direction: "down" },
            { label: "NPS", delta: "+11", direction: "up" },
          ],
          dataSources: ["Branch logs", "ATM", "IVR", "Mobile", "Web"],
          maturity: "Pilot",
          tags: ["omnichannel", "journey", "cx"],
        },
        {
          id: "bnk-rb-05",
          title: "Wallet-to-Bank Money-Mule Triangulation",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Triangulates wallet cash-outs, beneficiary additions and onward remittance to surface mule networks that pass between fintech and bank rails.",
          capabilities: ["hypergraph", "anomaly-detection", "topology"],
          surfaces: ["Fincrime ops", "Wallet partner API", "Suspicious-activity reporting"],
          kpis: [
            { label: "Mule accounts flagged", delta: "+421", direction: "up" },
            { label: "SAR cycle time", delta: "−63%", direction: "down" },
          ],
          dataSources: ["Wallet rails", "Beneficiary graph", "Onward remittance"],
          maturity: "Production",
          tags: ["mule", "fincrime", "wallet", "hypergraph"],
        },
        {
          id: "bnk-rb-06",
          title: "Micro-Segment Pricing for Loans",
          industry: "Banking",
          subIndustry: "Retail Banking",
          summary:
            "Spectral clustering carves the book into thousands of micro-segments; RL tunes rate sheets per segment against conversion and loss curves.",
          capabilities: ["spectral", "rl-optimization", "neuro-symbolic"],
          surfaces: ["Pricing engine", "Origination", "Risk-ledger"],
          kpis: [
            { label: "Conversion", delta: "+9%", direction: "up" },
            { label: "Yield", delta: "+38bps", direction: "up" },
          ],
          dataSources: ["Loan book", "Bureau", "Behavioural bureau"],
          maturity: "R&D",
          tags: ["pricing", "segmentation", "rl", "loans"],
        },
      ],
    },
    {
      id: "corporate-banking",
      name: "Corporate & Commercial Banking",
      description: "Lending, treasury, cash management and trade for corporates.",
      useCases: [
        {
          id: "bnk-cb-01",
          title: "Supply-Chain Finance Risk Propagation",
          industry: "Banking",
          subIndustry: "Corporate & Commercial Banking",
          summary:
            "Maps buyer-supplier-shipment-lender edges; a single supplier default propagates through the graph to predict exposure across the book.",
          capabilities: ["dynamic-graph", "topology", "neuro-symbolic"],
          surfaces: ["Credit risk", "Treasury", "Trade-finance desk"],
          kpis: [
            { label: "Concentration loss avoided", delta: "$24M", direction: "up" },
            { label: "Exposure heat-map refresh", delta: "real-time", direction: "up" },
          ],
          dataSources: ["Invoices", "Shipments", "Bureau", "News"],
          maturity: "Production",
          tags: ["supply-chain", "credit", "propagation", "trade"],
        },
        {
          id: "bnk-cb-02",
          title: "Syndicated Loan Network Analytics",
          industry: "Banking",
          subIndustry: "Corporate & Commercial Banking",
          summary:
            "Models agent bank, participant, borrower and guarantor as a hypergraph to surface concentration and conflict-of-interest before syndication closes.",
          capabilities: ["hypergraph", "spectral", "neuro-symbolic"],
          surfaces: ["Syndication desk", "Compliance", "Credit committee"],
          kpis: [
            { label: "Conflict flags pre-close", delta: "+18", direction: "up" },
            { label: "Deal-cycle time", delta: "−12%", direction: "down" },
          ],
          dataSources: ["Deal tracker", "LEI registry", "Counterparty graph"],
          maturity: "Deployed",
          tags: ["syndication", "loan", "hypergraph", "compliance"],
        },
        {
          id: "bnk-cb-03",
          title: "Cash-Pool Leak Detection",
          industry: "Banking",
          subIndustry: "Corporate & Commercial Banking",
          summary:
            "Traces intra-day sweeps across cash pools to spot leakage patterns indicative of error, fraud or treasury policy breach.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Treasury ops", "Cash-management platform", "Audit"],
          kpis: [
            { label: "Leakage recovered", delta: "$3.1M", direction: "up" },
            { label: "Reconciliation effort", delta: "−47%", direction: "down" },
          ],
          dataSources: ["Intra-day SWIFT", "ERP", "Cash-pool ledger"],
          maturity: "Deployed",
          tags: ["treasury", "cash-pool", "leakage", "real-time"],
        },
        {
          id: "bnk-cb-04",
          title: "Borrower Cohort Early-Warning",
          industry: "Banking",
          subIndustry: "Corporate & Commercial Banking",
          summary:
            "Spectral embedding of financial ratios, sector and news signals clusters borrowers; cohort drift predicts sector stress ahead of default.",
          capabilities: ["spectral", "anomaly-detection", "multi-modal"],
          surfaces: ["Credit monitoring", "Watchlist", "Provisioning"],
          kpis: [
            { label: "Watchlist lead time", delta: "+94d", direction: "up" },
            { label: "Provision accuracy", delta: "+22%", direction: "up" },
          ],
          dataSources: ["Financials", "Sector indices", "News", "Bureau"],
          maturity: "Production",
          tags: ["early-warning", "credit", "cohort", "spectral"],
        },
        {
          id: "bnk-cb-05",
          title: "Trade-Finance Document Graph",
          industry: "Banking",
          subIndustry: "Corporate & Commercial Banking",
          summary:
            "Hypergraph of LCs, bills of lading, invoices and inspection certs surfaces double-financing and document forgery rings.",
          capabilities: ["hypergraph", "generative", "neuro-symbolic"],
          surfaces: ["Trade ops", "Compliance", "Document AI"],
          kpis: [
            { label: "Double-financing caught", delta: "$8.7M", direction: "up" },
            { label: "Doc-check turnaround", delta: "−71%", direction: "down" },
          ],
          dataSources: ["LC", "BoL", "Invoices", "Customs"],
          maturity: "Pilot",
          tags: ["trade-finance", "lc", "document", "hypergraph"],
        },
      ],
    },
    {
      id: "payments",
      name: "Payments & Rails",
      description: "Cards, RTGS, NEFT, UPI, SWIFT, instant payments.",
      useCases: [
        {
          id: "bnk-pm-01",
          title: "Real-Time UPI / Fast-Pay Fraud Interdiction",
          industry: "Banking",
          subIndustry: "Payments & Rails",
          summary:
            "Streaming graph scores each payment in <50ms against the live counterparty graph; high-risk transactions are held for step-up auth.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph", "quantum-embedding"],
          surfaces: ["Payment switch", "Fraud engine", "Step-up auth"],
          kpis: [
            { label: "Fraud loss / txn", delta: "−61%", direction: "down" },
            { label: "False positives", delta: "−44%", direction: "down" },
          ],
          dataSources: ["UPI rails", "Device graph", "VPA history"],
          maturity: "Production",
          tags: ["upi", "instant-pay", "fraud", "real-time"],
        },
        {
          id: "bnk-pm-02",
          title: "Card-Not-Present Merchant Risk Graph",
          industry: "Banking",
          subIndustry: "Payments & Rails",
          summary:
            "Aggregates cardholder, merchant, BIN and IP into a graph; merchant cohorts that suddenly drift signal bust-out or synthetic-merchant fraud.",
          capabilities: ["dynamic-graph", "anomaly-detection", "topology"],
          surfaces: ["Card fraud engine", "Acquirer risk", "Chargeback ops"],
          kpis: [
            { label: "Chargeback rate", delta: "−33%", direction: "down" },
            { label: "Bust-out merchants caught", delta: "+57", direction: "up" },
          ],
          dataSources: ["Auth stream", "Merchant master", "Chargebacks"],
          maturity: "Deployed",
          tags: ["cnp", "card", "merchant", "bust-out"],
        },
        {
          id: "bnk-pm-03",
          title: "Cross-Border Correspondent Path Optimization",
          industry: "Banking",
          subIndustry: "Payments & Rails",
          summary:
            "RL agent learns the cheapest, fastest, least-sanction-risk correspondent path per currency corridor from the live SWIFT graph.",
          capabilities: ["rl-optimization", "dynamic-graph", "neuro-symbolic"],
          surfaces: ["Payments hub", "Treasury", "Sanctions screening"],
          kpis: [
            { label: "Avg. corridor cost", delta: "−18%", direction: "down" },
            { label: "Straight-through rate", delta: "+11%", direction: "up" },
          ],
          dataSources: ["SWIFT", "Correspondent master", "Sanctions lists"],
          maturity: "Pilot",
          tags: ["cross-border", "swift", "correspondent", "rl"],
        },
        {
          id: "bnk-pm-04",
          title: "Laundering Layering Detection",
          industry: "Banking",
          subIndustry: "Payments & Rails",
          summary:
            "Persistent-homology analysis of fund-flow subgraphs detects multi-hop layering topologies that rule-based AML misses.",
          capabilities: ["topology", "anomaly-detection", "streaming"],
          surfaces: ["AML ops", "SAR workflow", "Case management"],
          kpis: [
            { label: "SAR quality score", delta: "+39%", direction: "up" },
            { label: "Alert noise", delta: "−58%", direction: "down" },
          ],
          dataSources: ["Transaction graph", "KYC", "Adverse media"],
          maturity: "Production",
          tags: ["aml", "layering", "topology", "laundering"],
        },
        {
          id: "bnk-pm-05",
          title: "Wallet Topology Anomaly",
          industry: "Banking",
          subIndustry: "Payments & Rails",
          summary:
            "Embeds wallet VPA / handle graphs to spot synthetic-account farms created for promo abuse and micro-laundering.",
          capabilities: ["spectral", "anomaly-detection", "generative"],
          surfaces: ["Wallet fraud", "Promo integrity", "Growth analytics"],
          kpis: [
            { label: "Promo abuse", delta: "−72%", direction: "down" },
            { label: "Synthetic farms caught", delta: "+1,204", direction: "up" },
          ],
          dataSources: ["Wallet rails", "Device graph", "Promo ledger"],
          maturity: "Deployed",
          tags: ["wallet", "promo-abuse", "synthetic", "embedding"],
        },
      ],
    },
    {
      id: "wealth",
      name: "Wealth & Private Banking",
      description: "Advisory, portfolio, trust and family-office services.",
      useCases: [
        {
          id: "bnk-wb-01",
          title: "Family-Office Relationship Graph",
          industry: "Banking",
          subIndustry: "Wealth & Private Banking",
          summary:
            "Hypergraph of trusts, holdings, beneficiaries and advisors reveals beneficial-ownership chains and conflict surfaces.",
          capabilities: ["hypergraph", "neuro-symbolic", "multi-modal"],
          surfaces: ["KYC refresh", "Advisor desktop", "Estate planning"],
          kpis: [
            { label: "UBO resolution time", delta: "−81%", direction: "down" },
            { label: "Conflict surfaces", delta: "+22", direction: "up" },
          ],
          dataSources: ["Trust deeds", "Registry", "Holdings", "Adverse media"],
          maturity: "Deployed",
          tags: ["family-office", "ubo", "trust", "hypergraph"],
        },
        {
          id: "bnk-wb-02",
          title: "Portfolio Contagion Stress",
          industry: "Banking",
          subIndustry: "Wealth & Private Banking",
          summary:
            "Models holdings, sector and counterparty links to simulate contagion across portfolios under user-defined shocks.",
          capabilities: ["dynamic-graph", "topology", "neuro-symbolic"],
          surfaces: ["Risk dashboards", "Advisor tools", "Investment committee"],
          kpis: [
            { label: "Shock scenarios / min", delta: "120", direction: "up" },
            { label: "Concentration breaches", delta: "+18 caught", direction: "up" },
          ],
          dataSources: ["Holdings", "Counterparty", "Market data"],
          maturity: "Pilot",
          tags: ["portfolio", "contagion", "stress", "risk"],
        },
        {
          id: "bnk-wb-03",
          title: "Advisor-Client Matchmaking",
          industry: "Banking",
          subIndustry: "Wealth & Private Banking",
          summary:
            "Spectral embedding of client goals, risk profile and advisor expertise to maximise relationship longevity.",
          capabilities: ["spectral", "rl-optimization"],
          surfaces: ["Advisor routing", "Book management"],
          kpis: [
            { label: "12-mo retention", delta: "+14%", direction: "up" },
            { label: "AUM growth per book", delta: "+7%", direction: "up" },
          ],
          dataSources: ["CRM", "Goal plan", "Advisor profile"],
          maturity: "R&D",
          tags: ["advisor", "matching", "aum", "rl"],
        },
      ],
    },
    {
      id: "fincrime",
      name: "Financial Crime & Compliance",
      description: "AML, sanctions, KYC, fraud and insider risk.",
      useCases: [
        {
          id: "bnk-fc-01",
          title: "Sanctions Evasion Network Detection",
          industry: "Banking",
          subIndustry: "Financial Crime & Compliance",
          summary:
            "Topological analytics surface beneficial-ownership chains designed to obscure sanctioned entities behind layered intermediaries.",
          capabilities: ["topology", "neuro-symbolic", "hypergraph"],
          surfaces: ["Sanctions screening", "Investigations", "Regulator reporting"],
          kpis: [
            { label: "True-positive rate", delta: "+47%", direction: "up" },
            { label: "Investigation hours", delta: "−53%", direction: "down" },
          ],
          dataSources: ["Ownership graph", "Sanctions", "Adverse media"],
          maturity: "Production",
          tags: ["sanctions", "ubo", "topology", "compliance"],
        },
        {
          id: "bnk-fc-02",
          title: "Insider-Trading Pattern Mining",
          industry: "Banking",
          subIndustry: "Financial Crime & Compliance",
          summary:
            "Fuses employee access logs, deal exposure and trading graphs to flag information-flow anomalies prior to material events.",
          capabilities: ["multi-modal", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Surveillance", "HR", "Compliance"],
          kpis: [
            { label: "Insider alerts precision", delta: "+31%", direction: "up" },
          ],
          dataSources: ["Access logs", "Deal calendar", "Trading graph"],
          maturity: "Deployed",
          tags: ["insider", "surveillance", "compliance"],
        },
        {
          id: "bnk-fc-03",
          title: "Synthetic-ID Disassembly",
          industry: "Banking",
          subIndustry: "Financial Crime & Compliance",
          summary:
            "Generative reconstruction completes partially-observed identity graphs; inconsistent reconstructions flag synthetic identities.",
          capabilities: ["generative", "anomaly-detection", "spectral"],
          surfaces: ["Onboarding", "Credit", "Fincrime"],
          kpis: [
            { label: "Synthetic IDs caught", delta: "+2,318", direction: "up" },
            { label: "Onboarding friction", delta: "−19%", direction: "down" },
          ],
          dataSources: ["Bureau", "Telco", "Device", "Public records"],
          maturity: "Production",
          tags: ["synthetic-id", "onboarding", "fraud"],
        },
        {
          id: "bnk-fc-04",
          title: "Trade-Based Money-Laundering Pricing Graph",
          industry: "Banking",
          subIndustry: "Financial Crime & Compliance",
          summary:
            "Compares invoice prices against a market-price graph; persistent deviations across a counterparty chain flag TBML.",
          capabilities: ["dynamic-graph", "neuro-symbolic", "anomaly-detection"],
          surfaces: ["Trade compliance", "Investigations"],
          kpis: [
            { label: "TBML cases prioritised", delta: "+28", direction: "up" },
          ],
          dataSources: ["Invoices", "Customs", "Market price feed"],
          maturity: "Pilot",
          tags: ["tbml", "trade", "laundering", "compliance"],
        },
      ],
    },
    {
      id: "treasury",
      name: "Treasury & Markets",
      description: "Funding, ALM, FX, derivatives and intraday liquidity.",
      useCases: [
        {
          id: "bnk-tr-01",
          title: "Intraday Liquidity Pressure Propagation",
          industry: "Banking",
          subIndustry: "Treasury & Markets",
          summary:
            "Live graph of correspondent, branch and currency flows predicts intraday liquidity squeezes 90 minutes ahead.",
          capabilities: ["streaming", "dynamic-graph", "rl-optimization"],
          surfaces: ["Treasury desk", "ALM", "Repo"],
          kpis: [
            { label: "Squeeze warnings", delta: "+94d ahead", direction: "up" },
            { label: "Buffer optimisation", delta: "$120M freed", direction: "up" },
          ],
          dataSources: ["RTGS", "Branch cash", "FX", "Repo"],
          maturity: "Production",
          tags: ["intraday", "liquidity", "treasury", "real-time"],
        },
        {
          id: "bnk-tr-02",
          title: "Counterparty Cluster Risk in Derivatives",
          industry: "Banking",
          subIndustry: "Treasury & Markets",
          summary:
            "Spectral clustering of CCP, bilateral and collateral edges isolates hidden counterparty clusters with concentrated CVA risk.",
          capabilities: ["spectral", "topology", "neuro-symbolic"],
          surfaces: ["XVA desk", "Counterparty risk", "Collateral"],
          kpis: [
            { label: "CVA surprise events", delta: "−37%", direction: "down" },
          ],
          dataSources: ["Trades", "Collateral", "CCP exposures"],
          maturity: "Deployed",
          tags: ["xva", "counterparty", "derivatives", "spectral"],
        },
        {
          id: "bnk-tr-03",
          title: "FX Benchmark Manipulation Surveillance",
          industry: "Banking",
          subIndustry: "Treasury & Markets",
          summary:
            "Streaming topology analysis of dealer-chat and order-book graphs flags collusive micro-structure around fixing windows.",
          capabilities: ["streaming", "topology", "anomaly-detection"],
          surfaces: ["Market surveillance", "Compliance"],
          kpis: [
            { label: "Surveillance alerts precision", delta: "+44%", direction: "up" },
          ],
          dataSources: ["Order book", "Chat", "Fixing data"],
          maturity: "Pilot",
          tags: ["fx", "surveillance", "manipulation", "real-time"],
        },
      ],
    },
  ],
};

/* =========================================================================
   PHARMA
   ========================================================================= */
const PHARMA: Industry = {
  id: "pharma",
  name: "Pharma & Life Sciences",
  code: "PHR",
  tagline: "From molecule to market — graph intelligence for the science of care.",
  description:
    "Pharma lives on graphs: molecules, targets, trials, providers, payers, patients. CIP unifies biology, evidence and commercial into a single contextual fabric — accelerating discovery, de-risking trials and personalising care.",
  accent: "#0d9488",
  icon: "Dna",
  metrics: [
    { label: "Molecule Graph", value: "240M", sub: "compounds + targets" },
    { label: "Trial Cycle Cut", value: "−19%", sub: "site-patient matching" },
    { label: "AE Signal Lead", value: "+38d", sub: "vs spontaneous reporting" },
    { label: "Rep Effectiveness", value: "+27%", sub: "HCP targeting uplift" },
  ],
  subIndustries: [
    {
      id: "discovery",
      name: "Drug Discovery & R&D",
      description: "Target identification, lead optimisation, preclinical.",
      useCases: [
        {
          id: "phr-ds-01",
          title: "Target-Disease Knowledge Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Drug Discovery & R&D",
          summary:
            "Fuses literature, omics and pathway databases into a target-disease graph; spectral ranking prioritises druggable targets with mechanistic support.",
          capabilities: ["multi-modal", "spectral", "neuro-symbolic", "compression"],
          surfaces: ["Target ID", "Portfolio review", "Biomarker discovery"],
          kpis: [
            { label: "Target shortlist precision", delta: "+42%", direction: "up" },
            { label: "Lit-review time", delta: "−68%", direction: "down" },
          ],
          dataSources: ["Literature", "Omics", "Pathway DB", "Patents"],
          maturity: "Production",
          tags: ["target-id", "knowledge-graph", "discovery"],
        },
        {
          id: "phr-ds-02",
          title: "Molecular Property Prediction",
          industry: "Pharma & Life Sciences",
          subIndustry: "Drug Discovery & R&D",
          summary:
            "Quantum-inspired embedding of molecular graphs predicts ADMET endpoints with calibrated uncertainty for library triage.",
          capabilities: ["quantum-embedding", "generative", "spectral"],
          surfaces: ["Med-chem", "ADMET", "Library design"],
          kpis: [
            { label: "ADMET accuracy", delta: "+14%", direction: "up" },
            { label: "Synthesis queue", delta: "−31%", direction: "down" },
          ],
          dataSources: ["Molecular graph", "Assay", "Historical ADMET"],
          maturity: "Deployed",
          tags: ["admet", "molecular-graph", "embedding"],
        },
        {
          id: "phr-ds-03",
          title: "Repurposing via Hypergraph of Indication",
          industry: "Pharma & Life Sciences",
          subIndustry: "Drug Discovery & R&D",
          summary:
            "Hypergraph of drug-target-pathway-indication surfaces repurposing candidates by shared mechanistic neighbourhood.",
          capabilities: ["hypergraph", "neuro-symbolic", "spectral"],
          surfaces: ["Repurposing pipeline", "Portfolio strategy"],
          kpis: [
            { label: "Repurposing candidates", delta: "+73", direction: "up" },
            { label: "Pre-clinical start rate", delta: "+18%", direction: "up" },
          ],
          dataSources: ["Drug-target", "Pathway", "Indication", "Trial"],
          maturity: "Pilot",
          tags: ["repurposing", "hypergraph", "indication"],
        },
        {
          id: "phr-ds-04",
          title: "Protein-Protein Interaction Inference",
          industry: "Pharma & Life Sciences",
          subIndustry: "Drug Discovery & R&D",
          summary:
            "Generative reconstruction completes partial PPI graphs; low-confidence reconstructions become prioritised wet-lab experiments.",
          capabilities: ["generative", "dynamic-graph", "topology"],
          surfaces: ["Systems biology", "Wet-lab queue"],
          kpis: [
            { label: "Wet-lab hit rate", delta: "+26%", direction: "up" },
          ],
          dataSources: ["PPI DB", "Co-expression", "Y2H"],
          maturity: "R&D",
          tags: ["ppi", "generative", "systems-biology"],
        },
        {
          id: "phr-ds-05",
          title: "Polypharmacology Mapping",
          industry: "Pharma & Life Sciences",
          subIndustry: "Drug Discovery & R&D",
          summary:
            "Embedding of compound-target edges predicts off-target binding; topology flags safety liability clusters before lead selection.",
          capabilities: ["spectral", "topology", "quantum-embedding"],
          surfaces: ["Safety assessment", "Lead selection"],
          kpis: [
            { label: "Off-target tox surprises", delta: "−29%", direction: "down" },
          ],
          dataSources: ["Binding assay", "Target similarity", "Tox DB"],
          maturity: "Deployed",
          tags: ["polypharmacology", "off-target", "safety"],
        },
      ],
    },
    {
      id: "clinical",
      name: "Clinical Development",
      description: "Trial design, site selection, patient recruitment, monitoring.",
      useCases: [
        {
          id: "phr-cl-01",
          title: "Trial-Site-Patient Matching Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Clinical Development",
          summary:
            "Hypergraph of protocol criteria, site capabilities and patient phenotypes matches patients to trials in real time.",
          capabilities: ["hypergraph", "streaming", "neuro-symbolic"],
          surfaces: ["Site selection", "Recruitment", "Protocol design"],
          kpis: [
            { label: "Enrolment cycle", delta: "−19%", direction: "down" },
            { label: "Screen-failure rate", delta: "−22%", direction: "down" },
          ],
          dataSources: ["EHR", "Site capability", "Protocol", "Registry"],
          maturity: "Production",
          tags: ["trial", "recruitment", "site", "matching"],
        },
        {
          id: "phr-cl-02",
          title: "Adverse-Event Signal Detection",
          industry: "Pharma & Life Sciences",
          subIndustry: "Clinical Development",
          summary:
            "Streaming topology analysis of AE, drug and patient graphs surfaces safety signals weeks ahead of spontaneous reporting.",
          capabilities: ["streaming", "topology", "anomaly-detection"],
          surfaces: ["Pharmacovigilance", "DSMB", "Regulator reporting"],
          kpis: [
            { label: "Signal lead vs FAERS", delta: "+38d", direction: "up" },
            { label: "False signals", delta: "−34%", direction: "down" },
          ],
          dataSources: ["AE DB", "EHR", "FAERS", "Literature"],
          maturity: "Production",
          tags: ["pharmacovigilance", "ae", "signal", "safety"],
        },
        {
          id: "phr-cl-03",
          title: "Protocol-Deviation Pattern Mining",
          industry: "Pharma & Life Sciences",
          subIndustry: "Clinical Development",
          summary:
            "Embedding of site, monitor and CRF graphs surfaces protocol-deviation clusters indicative of training or data-quality issues.",
          capabilities: ["spectral", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Clinical ops", "Monitoring", "Data management"],
          kpis: [
            { label: "Deviations caught early", delta: "+47%", direction: "up" },
            { label: "Monitoring visits", delta: "−18%", direction: "down" },
          ],
          dataSources: ["EDC", "Monitoring visit", "Site master"],
          maturity: "Deployed",
          tags: ["protocol", "deviation", "monitoring", "data-quality"],
        },
        {
          id: "phr-cl-04",
          title: "Real-World Evidence Cohort Builder",
          industry: "Pharma & Life Sciences",
          subIndustry: "Clinical Development",
          summary:
            "Multi-modal fusion of EHR, claims and device data constructs RWE cohorts aligned to trial populations for external control arms.",
          capabilities: ["multi-modal", "neuro-symbolic", "compression"],
          surfaces: ["RWE", "HEOR", "Regulator submission"],
          kpis: [
            { label: "Cohort build time", delta: "−74%", direction: "down" },
            { label: "Cohort fidelity score", delta: "+19%", direction: "up" },
          ],
          dataSources: ["EHR", "Claims", "Device", "Patient registry"],
          maturity: "Pilot",
          tags: ["rwe", "cohort", "external-control", "heor"],
        },
      ],
    },
    {
      id: "commercial",
      name: "Commercial & Market Access",
      description: "Launch, promotion, payer engagement, HCP targeting.",
      useCases: [
        {
          id: "phr-cm-01",
          title: "HCP-Patient Influence Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Commercial & Market Access",
          summary:
            "Models patient-sharing edges between HCPs to identify true opinion-leaders and optimise rep deployment.",
          capabilities: ["dynamic-graph", "spectral", "rl-optimization"],
          surfaces: ["Field force", "Omnichannel", "KOL strategy"],
          kpis: [
            { label: "Rep effectiveness", delta: "+27%", direction: "up" },
            { label: "Reach efficiency", delta: "+33%", direction: "up" },
          ],
          dataSources: ["Claims", "Prescription", "Affiliation", "Conf-attendance"],
          maturity: "Production",
          tags: ["hcp", "kol", "influence", "field-force"],
        },
        {
          id: "phr-cm-02",
          title: "Payer Evidence Pack Generator",
          industry: "Pharma & Life Sciences",
          subIndustry: "Commercial & Market Access",
          summary:
            "Neuro-symbolic reasoning compiles payer-grade evidence packs by traversing trial-RWE-publication graph for each indication.",
          capabilities: ["neuro-symbolic", "multi-modal", "dynamic-graph"],
          surfaces: ["Market access", "HEOR", "Payer engagement"],
          kpis: [
            { label: "Pack build time", delta: "−61%", direction: "down" },
            { label: "Formulary win rate", delta: "+11%", direction: "up" },
          ],
          dataSources: ["Trial", "RWE", "Publication", "Guidelines"],
          maturity: "Deployed",
          tags: ["payer", "market-access", "evidence", "heor"],
        },
        {
          id: "phr-cm-03",
          title: "Launch Demand Forecasting on Adoption Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Commercial & Market Access",
          summary:
            "RL-tuned adoption model propagates through HCP influence graph to forecast launch uptake by region and segment.",
          capabilities: ["rl-optimization", "dynamic-graph", "spectral"],
          surfaces: ["Forecasting", "Supply planning", "Launch ops"],
          kpis: [
            { label: "Forecast MAPE", delta: "−29%", direction: "down" },
            { label: "Stock-out events", delta: "−44%", direction: "down" },
          ],
          dataSources: ["Adoption logs", "Influence graph", "Epidemiology"],
          maturity: "Pilot",
          tags: ["launch", "forecast", "adoption", "rl"],
        },
        {
          id: "phr-cm-04",
          title: "Sample & Speaker Program Integrity",
          industry: "Pharma & Life Sciences",
          subIndustry: "Commercial & Market Access",
          summary:
            "Anomaly detection across sample, speaker and HCP graphs surfaces compliance deviations in promotional spend.",
          capabilities: ["anomaly-detection", "topology", "neuro-symbolic"],
          surfaces: ["Compliance", "Commercial ops"],
          kpis: [
            { label: "Compliance flags precision", delta: "+38%", direction: "up" },
          ],
          dataSources: ["Sample ledger", "Speaker events", "HCP master"],
          maturity: "Deployed",
          tags: ["sample", "speaker", "compliance", "promotion"],
        },
      ],
    },
    {
      id: "manufacturing",
      name: "Pharma Manufacturing & Supply",
      description: "API, formulation, batch, cold chain and quality.",
      useCases: [
        {
          id: "phr-mf-01",
          title: "Batch Deviation Root-Cause Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Pharma Manufacturing & Supply",
          summary:
            "Fuses batch records, equipment, raw-material and personnel graphs to surface the smallest causally-linked subgraph behind a deviation.",
          capabilities: ["dynamic-graph", "neuro-symbolic", "topology"],
          surfaces: ["QA", "Manufacturing science", "CAPA"],
          kpis: [
            { label: "Root-cause time", delta: "−57%", direction: "down" },
            { label: "Repeat deviations", delta: "−31%", direction: "down" },
          ],
          dataSources: ["Batch record", "MES", "LIMS", "ERP"],
          maturity: "Production",
          tags: ["batch", "deviation", "root-cause", "quality"],
        },
        {
          id: "phr-mf-02",
          title: "Cold-Chain Anomaly Interdiction",
          industry: "Pharma & Life Sciences",
          subIndustry: "Pharma Manufacturing & Supply",
          summary:
            "Streaming graph of shipments, sensors and lanes flags temperature excursions and predicts potency loss before delivery.",
          capabilities: ["streaming", "anomaly-detection", "rl-optimization"],
          surfaces: ["Logistics", "QA", "Warehouse"],
          kpis: [
            { label: "Excursion loss", delta: "−48%", direction: "down" },
            { label: "On-time in-full", delta: "+9%", direction: "up" },
          ],
          dataSources: ["IoT sensors", "TMS", "WMS"],
          maturity: "Deployed",
          tags: ["cold-chain", "iot", "supply", "real-time"],
        },
        {
          id: "phr-mf-03",
          title: "Raw-Material Supply Concentration Risk",
          industry: "Pharma & Life Sciences",
          subIndustry: "Pharma Manufacturing & Supply",
          summary:
            "Hypergraph of supplier-site-API-formulation exposes concentration and geopolitical risk across the multi-tier bill of materials.",
          capabilities: ["hypergraph", "neuro-symbolic", "topology"],
          surfaces: ["Sourcing", "Risk", "Business continuity"],
          kpis: [
            { label: "Single-source SKUs flagged", delta: "+58", direction: "up" },
            { label: "Mitigation lead time", delta: "+30d", direction: "up" },
          ],
          dataSources: ["BOM", "Supplier master", "Geopolitical feed"],
          maturity: "Pilot",
          tags: ["supplier", "concentration", "risk", "sourcing"],
        },
      ],
    },
    {
      id: "pharmacovigilance",
      name: "Pharmacovigilance & Safety",
      description: "Post-market surveillance, signal management, regulator reporting.",
      useCases: [
        {
          id: "phr-pv-01",
          title: "Cross-Source Signal Triangulation",
          industry: "Pharma & Life Sciences",
          subIndustry: "Pharmacovigilance & Safety",
          summary:
            "Multi-modal fusion of FAERS, EHR, literature and social media triangulates weak signals invisible in any single source.",
          capabilities: ["multi-modal", "streaming", "topology", "neuro-symbolic"],
          surfaces: ["Signal management", "PSUR", "Regulator"],
          kpis: [
            { label: "Validated signals / quarter", delta: "+12", direction: "up" },
            { label: "Mean time to validate", delta: "−44%", direction: "down" },
          ],
          dataSources: ["FAERS", "EHR", "Literature", "Social"],
          maturity: "Production",
          tags: ["pv", "signal", "faers", "multi-modal"],
        },
        {
          id: "phr-pv-02",
          title: "Medication-Error Pattern Topology",
          industry: "Pharma & Life Sciences",
          subIndustry: "Pharmacovigilance & Safety",
          summary:
            "Persistent-homology analysis of error reports finds recurring structural patterns across products, settings and workflows.",
          capabilities: ["topology", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Medication safety", "Risk management"],
          kpis: [
            { label: "Error patterns surfaced", delta: "+21", direction: "up" },
          ],
          dataSources: ["Error reports", "EHR", "Workflow logs"],
          maturity: "Deployed",
          tags: ["medication-error", "topology", "safety"],
        },
      ],
    },
    {
      id: "precision-medicine",
      name: "Precision Medicine & Diagnostics",
      description: "Biomarkers, companion diagnostics, patient stratification.",
      useCases: [
        {
          id: "phr-pm-01",
          title: "Patient Stratification by Multi-Omic Graph",
          industry: "Pharma & Life Sciences",
          subIndustry: "Precision Medicine & Diagnostics",
          summary:
            "Hypergraph of genomic, transcriptomic and clinical data identifies responder sub-populations for therapy assignment.",
          capabilities: ["hypergraph", "multi-modal", "spectral", "quantum-embedding"],
          surfaces: ["Companion dx", "Therapy selection", "Trial enrichment"],
          kpis: [
            { label: "Responder stratification", delta: "+24%", direction: "up" },
          ],
          dataSources: ["Genomic", "Transcriptomic", "Clinical", "Imaging"],
          maturity: "Pilot",
          tags: ["precision", "stratification", "omics", "companion-dx"],
        },
        {
          id: "phr-pm-02",
          title: "Disease Trajectory Prediction",
          industry: "Pharma & Life Sciences",
          subIndustry: "Precision Medicine & Diagnostics",
          summary:
            "Embedding of patient-journey graphs predicts transition to severe phenotypes for early intervention.",
          capabilities: ["spectral", "dynamic-graph", "rl-optimization"],
          surfaces: ["Care management", "Population health"],
          kpis: [
            { label: "High-risk patients flagged", delta: "+1,840", direction: "up" },
            { label: "Intervention lead", delta: "+90d", direction: "up" },
          ],
          dataSources: ["EHR", "Claims", "Device"],
          maturity: "R&D",
          tags: ["trajectory", "prediction", "precision", "population-health"],
        },
      ],
    },
  ],
};

/* =========================================================================
   FINANCE  (capital markets, asset management, fintech, lending, esg)
   ========================================================================= */
const FINANCE: Industry = {
  id: "finance",
  name: "Finance & Capital Markets",
  code: "FIN",
  tagline: "Contextual alpha across markets, credit and climate.",
  description:
    "Capital markets are graphs of issuers, instruments, factor exposures and flows. CIP fuses prices, fundamentals, alt-data and ESG into a single contextual layer — surfacing alpha, liquidity and risk that point-in-time analytics cannot see.",
  accent: "#7c3aed",
  icon: "CandlestickChart",
  metrics: [
    { label: "Issuer Universe", value: "94K", sub: "global entities covered" },
    { label: "Alt-Data Streams", value: "1,200+", sub: "ingested continuously" },
    { label: "Signal Decay", value: "−41%", sub: "alpha half-life extension" },
    { label: "ESG Coverage", value: "8,400", sub: "controversy-linked issuers" },
  ],
  subIndustries: [
    {
      id: "asset-management",
      name: "Asset Management",
      description: "Long-only, hedge, quant and private market managers.",
      useCases: [
        {
          id: "fin-am-01",
          title: "Factor-Contagion Early Warning",
          industry: "Finance & Capital Markets",
          subIndustry: "Asset Management",
          summary:
            "Spectral analysis of factor co-movement graphs predicts regime shifts and crowding before they hit P&L.",
          capabilities: ["spectral", "topology", "streaming"],
          surfaces: ["Risk", "Portfolio construction", "Trading"],
          kpis: [
            { label: "Regime-shift lead", delta: "+6d", direction: "up" },
            { label: "Crowding drawdowns avoided", delta: "+180bps", direction: "up" },
          ],
          dataSources: ["Factor returns", "Positioning", "Flow"],
          maturity: "Production",
          tags: ["factor", "contagion", "crowding", "regime"],
        },
        {
          id: "fin-am-02",
          title: "Issuer Relationship Alpha Graph",
          industry: "Finance & Capital Markets",
          subIndustry: "Asset Management",
          summary:
            "Hypergraph of issuer-subsidiary-supplier-customer edges propagates fundamental signals across related issuers.",
          capabilities: ["hypergraph", "neuro-symbolic", "dynamic-graph"],
          surfaces: ["Research", "Alpha research", "Portfolio"],
          kpis: [
            { label: "Signal IC", delta: "+0.04", direction: "up" },
            { label: "Idea generation", delta: "+38/wk", direction: "up" },
          ],
          dataSources: ["Ownership", "Supply-chain", "Filings", "News"],
          maturity: "Deployed",
          tags: ["alpha", "issuer", "relationship", "research"],
        },
        {
          id: "fin-am-03",
          title: "Private-Markets Comparable Graph",
          industry: "Finance & Capital Markets",
          subIndustry: "Asset Management",
          summary:
            "Embedding of private-company, round and investor graphs surfaces comparables for mark and exit analysis.",
          capabilities: ["spectral", "generative", "multi-modal"],
          surfaces: ["Private equity", "Venture", "Valuation"],
          kpis: [
            { label: "Valuation accuracy", delta: "+22%", direction: "up" },
          ],
          dataSources: ["Cap-table", "Round history", "Investor graph"],
          maturity: "Pilot",
          tags: ["private-markets", "venture", "valuation", "comparables"],
        },
        {
          id: "fin-am-04",
          title: "Liquidity-Aware Execution Pathing",
          industry: "Finance & Capital Markets",
          subIndustry: "Asset Management",
          summary:
            "RL agent learns venue-venue-impact graph to minimise slippage and market-impact for large parent orders.",
          capabilities: ["rl-optimization", "streaming", "dynamic-graph"],
          surfaces: ["EMS", "Trading desk", "TCA"],
          kpis: [
            { label: "Slippage vs arrival", delta: "−12bps", direction: "down" },
          ],
          dataSources: ["Order book", "Venue", "TCA"],
          maturity: "Deployed",
          tags: ["execution", "liquidity", "rl", "tca"],
        },
      ],
    },
    {
      id: "capital-markets",
      name: "Capital Markets & Exchanges",
      description: "Listings, exchanges, CCPs, indices and data vendors.",
      useCases: [
        {
          id: "fin-cm-01",
          title: "Market-Manipulation Topology Surveillance",
          industry: "Finance & Capital Markets",
          subIndustry: "Capital Markets & Exchanges",
          summary:
            "Streaming topology analysis of order-book, account and IP graphs flags spoofing and layering rings in microseconds.",
          capabilities: ["streaming", "topology", "anomaly-detection"],
          surfaces: ["Market surveillance", "Regulator liaison"],
          kpis: [
            { label: "Spoofing alerts precision", delta: "+51%", direction: "up" },
            { label: "Alert noise", delta: "−47%", direction: "down" },
          ],
          dataSources: ["Order book", "Account master", "Network"],
          maturity: "Production",
          tags: ["surveillance", "spoofing", "manipulation", "exchange"],
        },
        {
          id: "fin-cm-02",
          title: "Index Rebalance Front-Run Detection",
          industry: "Finance & Capital Markets",
          subIndustry: "Capital Markets & Exchanges",
          summary:
            "Embedding of rebalance flows, positioning and account clusters detects front-running around index events.",
          capabilities: ["spectral", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Surveillance", "Index ops"],
          kpis: [
            { label: "Front-run cases escalated", delta: "+18", direction: "up" },
          ],
          dataSources: ["Index changes", "Positioning", "Account graph"],
          maturity: "Pilot",
          tags: ["index", "rebalance", "front-running", "surveillance"],
        },
        {
          id: "fin-cm-03",
          title: "Issuer Default Propagation",
          industry: "Finance & Capital Markets",
          subIndustry: "Capital Markets & Exchanges",
          summary:
            "Live issuer-supplier-counterparty graph simulates default propagation across the listed universe for circuit-breaker tuning.",
          capabilities: ["dynamic-graph", "topology", "neuro-symbolic"],
          surfaces: ["Risk", "Exchange operations", "Regulator"],
          kpis: [
            { label: "Propagation scenarios / min", delta: "240", direction: "up" },
          ],
          dataSources: ["Issuer graph", "Counterparty", "Market data"],
          maturity: "R&D",
          tags: ["default", "propagation", "circuit-breaker"],
        },
      ],
    },
    {
      id: "lending",
      name: "Lending & Credit",
      description: "Consumer, SME, mortgage, BNPL, specialty finance.",
      useCases: [
        {
          id: "fin-ln-01",
          title: "SME Credit Network Underwriting",
          industry: "Finance & Capital Markets",
          subIndustry: "Lending & Credit",
          summary:
            "Hypergraph of SME-owner-supplier-buyer-bureau edges underwrites thin-file borrowers using network signals.",
          capabilities: ["hypergraph", "neuro-symbolic", "spectral"],
          surfaces: ["Underwriting", "Pricing", "Portfolio"],
          kpis: [
            { label: "Approval rate (thin-file)", delta: "+19%", direction: "up" },
            { label: "Loss rate", delta: "−23%", direction: "down" },
          ],
          dataSources: ["Bureau", "Bank statements", "Supply-chain", "Tax"],
          maturity: "Production",
          tags: ["sme", "underwriting", "thin-file", "credit"],
        },
        {
          id: "fin-ln-02",
          title: "BNPL Fraud Ring Interdiction",
          industry: "Finance & Capital Markets",
          subIndustry: "Lending & Credit",
          summary:
            "Streaming graph of device, merchant and repayment edges detects coordinated first-party fraud at checkout.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Fraud engine", "Merchant risk", "Checkout"],
          kpis: [
            { label: "Fraud loss rate", delta: "−57%", direction: "down" },
            { label: "Good-user friction", delta: "−31%", direction: "down" },
          ],
          dataSources: ["Checkout", "Device", "Merchant", "Repayment"],
          maturity: "Deployed",
          tags: ["bnpl", "fraud", "checkout", "real-time"],
        },
        {
          id: "fin-ln-03",
          title: "Mortgage Collateral Graph Valuation",
          industry: "Finance & Capital Markets",
          subIndustry: "Lending & Credit",
          summary:
            "Embedding of comparable, neighbourhood and transaction graphs values collateral with calibrated uncertainty.",
          capabilities: ["spectral", "generative", "multi-modal"],
          surfaces: ["Origination", "Appraisal review", "Portfolio"],
          kpis: [
            { label: "Valuation error", delta: "−26%", direction: "down" },
            { label: "Appraisal turnaround", delta: "−52%", direction: "down" },
          ],
          dataSources: ["Transaction", "Property graph", "Geospatial"],
          maturity: "Pilot",
          tags: ["mortgage", "collateral", "valuation", "avm"],
        },
        {
          id: "fin-ln-04",
          title: "Early-Warning Delinquency Propagation",
          industry: "Finance & Capital Markets",
          subIndustry: "Lending & Credit",
          summary:
            "Topology of borrower-employer-geography edges predicts delinquency clusters forming in a portfolio.",
          capabilities: ["topology", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Portfolio risk", "Collections", "Provisioning"],
          kpis: [
            { label: "Early-warning lead", delta: "+47d", direction: "up" },
          ],
          dataSources: ["Loan book", "Employer", "Macro"],
          maturity: "Deployed",
          tags: ["delinquency", "early-warning", "collections", "provisioning"],
        },
      ],
    },
    {
      id: "fintech",
      name: "Fintech & Digital Assets",
      description: "Neobanks, crypto, embedded finance, BNPL, wealth-tech.",
      useCases: [
        {
          id: "fin-ft-01",
          title: "On-Chain Laundering Topology",
          industry: "Finance & Capital Markets",
          subIndustry: "Fintech & Digital Assets",
          summary:
            "Persistent-homology analysis of wallet-transfer subgraphs detects cross-chain laundering topologies.",
          capabilities: ["topology", "streaming", "anomaly-detection"],
          surfaces: ["Compliance", "Regulator", "Risk"],
          kpis: [
            { label: "Laundering clusters found", delta: "+312", direction: "up" },
            { label: "False alerts", delta: "−63%", direction: "down" },
          ],
          dataSources: ["On-chain", "Off-chain", "Adverse media"],
          maturity: "Production",
          tags: ["crypto", "on-chain", "laundering", "topology"],
        },
        {
          id: "fin-ft-02",
          title: "DeFi Composability Risk Graph",
          industry: "Finance & Capital Markets",
          subIndustry: "Fintech & Digital Assets",
          summary:
            "Hypergraph of protocol dependencies simulates cascading liquidation across DeFi stacks.",
          capabilities: ["hypergraph", "dynamic-graph", "neuro-symbolic"],
          surfaces: ["Treasury", "Risk", "Protocol design"],
          kpis: [
            { label: "Cascade scenarios / min", delta: "180", direction: "up" },
          ],
          dataSources: ["Protocol state", "Oracle", "Liquidation"],
          maturity: "R&D",
          tags: ["defi", "composability", "cascade", "risk"],
        },
        {
          id: "fin-ft-03",
          title: "Neobank Viral-Growth Loop Optimisation",
          industry: "Finance & Capital Markets",
          subIndustry: "Fintech & Digital Assets",
          summary:
            "RL tunes referral incentives by traversing the invite graph to maximise high-LTV acquisitions.",
          capabilities: ["rl-optimization", "spectral", "dynamic-graph"],
          surfaces: ["Growth", "Loyalty", "Marketing"],
          kpis: [
            { label: "LTV of acquired", delta: "+34%", direction: "up" },
            { label: "CAC", delta: "−22%", direction: "down" },
          ],
          dataSources: ["Invite graph", "Transaction", "LTV model"],
          maturity: "Deployed",
          tags: ["neobank", "growth", "referral", "rl"],
        },
      ],
    },
    {
      id: "esg",
      name: "ESG & Climate Finance",
      description: "Controversies, transition risk, greenwashing, supply-chain ESG.",
      useCases: [
        {
          id: "fin-esg-01",
          title: "Supply-Chain Controversy Propagation",
          industry: "Finance & Capital Markets",
          subIndustry: "ESG & Climate Finance",
          summary:
            "Fuses supplier-customer graph with controversy feed to propagate ESG controversies up the ownership chain.",
          capabilities: ["dynamic-graph", "multi-modal", "neuro-symbolic"],
          surfaces: ["ESG research", "Stewardship", "Risk"],
          kpis: [
            { label: "Controversy lead vs news", delta: "+11d", direction: "up" },
            { label: "Coverage breadth", delta: "+8,400 issuers", direction: "up" },
          ],
          dataSources: ["Supplier graph", "Controversy feed", "News"],
          maturity: "Production",
          tags: ["esg", "controversy", "supply-chain", "stewardship"],
        },
        {
          id: "fin-esg-02",
          title: "Transition-Risk Network Stress",
          industry: "Finance & Capital Markets",
          subIndustry: "ESG & Climate Finance",
          summary:
            "Hypergraph of issuer-facility-emission edges simulates transition shocks across portfolios under NGFS scenarios.",
          capabilities: ["hypergraph", "topology", "neuro-symbolic"],
          surfaces: ["Climate risk", "Portfolio", "Regulator"],
          kpis: [
            { label: "Scenarios / min", delta: "90", direction: "up" },
          ],
          dataSources: ["Asset-level", "Emissions", "Scenario"],
          maturity: "Pilot",
          tags: ["climate", "transition-risk", "ngfs", "stress"],
        },
        {
          id: "fin-esg-03",
          title: "Greenwashing Detection in Disclosure Graph",
          industry: "Finance & Capital Markets",
          subIndustry: "ESG & Climate Finance",
          summary:
            "Neuro-symbolic reasoning compares disclosed initiatives, third-party ratings and on-the-ground signals to flag greenwashing.",
          capabilities: ["neuro-symbolic", "multi-modal", "anomaly-detection"],
          surfaces: ["ESG research", "Stewardship", "Regulator"],
          kpis: [
            { label: "Greenwashing flags", delta: "+47", direction: "up" },
          ],
          dataSources: ["Disclosure", "Ratings", "Satellite", "News"],
          maturity: "R&D",
          tags: ["greenwashing", "disclosure", "esg", "stewardship"],
        },
      ],
    },
    {
      id: "insurance-finance",
      name: "Insurance Investment Office",
      description: "Insurer ALM, credit book, reinsurance and CAT.",
      useCases: [
        {
          id: "fin-if-01",
          title: "Reinsurance Counterparty Cluster Risk",
          industry: "Finance & Capital Markets",
          subIndustry: "Insurance Investment Office",
          summary:
            "Hypergraph of cedant-broker-reinsurer-retrocession edges isolates hidden clusters with correlated recoverable risk.",
          capabilities: ["hypergraph", "spectral", "topology"],
          surfaces: ["Reinsurance", "ALM", "Counterparty risk"],
          kpis: [
            { label: "Concentration breaches", delta: "+14 caught", direction: "up" },
          ],
          dataSources: ["Ceded treaties", "Counterparty", "Credit"],
          maturity: "Deployed",
          tags: ["reinsurance", "counterparty", "cluster", "retrocession"],
        },
        {
          id: "fin-if-02",
          title: "CAT-Bond & ILS Spread Topology",
          industry: "Finance & Capital Markets",
          subIndustry: "Insurance Investment Office",
          summary:
            "Embedding of peril-exposure and spread graphs surfaces mispriced ILS tranches.",
          capabilities: ["spectral", "generative", "multi-modal"],
          surfaces: ["ILS portfolio", "Trading"],
          kpis: [
            { label: "Mispriced tranches found", delta: "+9/qtr", direction: "up" },
          ],
          dataSources: ["Peril model", "Trade", "Exposure"],
          maturity: "Pilot",
          tags: ["cat-bond", "ils", "spread", "peril"],
        },
      ],
    },
  ],
};

/* =========================================================================
   INSURANCE
   ========================================================================= */
const INSURANCE: Industry = {
  id: "insurance",
  name: "Insurance",
  code: "INS",
  tagline: "Underwriting, claims and fraud as one continuous graph.",
  description:
    "Insurance is a graph business — policyholders, drivers, vehicles, providers, repair shops, claims handlers and counterparties. CIP unifies policy, claim and exposure data to price tighter, settle faster and stop leakage before it spreads.",
  accent: "#ea580c",
  icon: "ShieldCheck",
  metrics: [
    { label: "Claim Graph", value: "780M", sub: "policies + claims + parties" },
    { label: "Fraud Catch Rate", value: "+39%", sub: "vs rules baseline" },
    { label: "Reserve Accuracy", value: "+24%", sub: "IBNR prediction uplift" },
    { label: "Claim Cycle", value: "−31%", sub: "FNOL to settlement" },
  ],
  subIndustries: [
    {
      id: "p-and-c",
      name: "Property & Casualty",
      description: "Auto, home, specialty, commercial lines.",
      useCases: [
        {
          id: "ins-pc-01",
          title: "Staged-Accident Ring Detection",
          industry: "Insurance",
          subIndustry: "Property & Casualty",
          summary:
            "Hypergraph of claimant, vehicle, repair-shop, witness and provider edges surfaces organised staged-accident rings.",
          capabilities: ["hypergraph", "anomaly-detection", "topology"],
          surfaces: ["Special investigation unit", "Claim ops", "Underwriting"],
          kpis: [
            { label: "Fraud $ recovered", delta: "$14M", direction: "up" },
            { label: "Ring size detected", delta: "+62", direction: "up" },
          ],
          dataSources: ["Claim", "Policy", "Repair-shop", "Provider"],
          maturity: "Production",
          tags: ["auto", "fraud", "staged-accident", "siu"],
        },
        {
          id: "ins-pc-02",
          title: "Reserve Prediction on Claim Graph",
          industry: "Insurance",
          subIndustry: "Property & Casualty",
          summary:
            "Embedding of claim features, parties and history predicts ultimate reserve with calibrated uncertainty.",
          capabilities: ["spectral", "generative", "neuro-symbolic"],
          surfaces: ["Reserving", "Actuarial", "Claim ops"],
          kpis: [
            { label: "Reserve accuracy", delta: "+24%", direction: "up" },
            { label: "IBNR volatility", delta: "−18%", direction: "down" },
          ],
          dataSources: ["Claim", "Policy", "Historical reserving"],
          maturity: "Deployed",
          tags: ["reserving", "ibnr", "actuarial", "claims"],
        },
        {
          id: "ins-pc-03",
          title: "CAT Exposure Aggregation",
          industry: "Insurance",
          subIndustry: "Property & Casualty",
          summary:
            "Live geospatial-policy-peril graph aggregates exposure in real time as a CAT unfolds; reroutes adjusters and reinsurance.",
          capabilities: ["streaming", "dynamic-graph", "rl-optimization"],
          surfaces: ["CAT desk", "Reinsurance", "Claims ops"],
          kpis: [
            { label: "Exposure refresh", delta: "real-time", direction: "up" },
            { label: "Adjuster routing efficiency", delta: "+27%", direction: "up" },
          ],
          dataSources: ["Policy location", "Peril feed", "Geo"],
          maturity: "Production",
          tags: ["cat", "exposure", "real-time", "peril"],
        },
        {
          id: "ins-pc-04",
          title: "Subrogation Opportunity Mining",
          industry: "Insurance",
          subIndustry: "Property & Casualty",
          summary:
            "Neuro-symbolic reasoning over claim, party and liability graphs surfaces recoverable subrogation opportunities.",
          capabilities: ["neuro-symbolic", "dynamic-graph", "spectral"],
          surfaces: ["Subrogation", "Recovery", "Claim ops"],
          kpis: [
            { label: "Recovery $", delta: "+31%", direction: "up" },
            { label: "Subro cases filed", delta: "+412", direction: "up" },
          ],
          dataSources: ["Claim", "Liability", "Party graph"],
          maturity: "Deployed",
          tags: ["subrogation", "recovery", "liability"],
        },
        {
          id: "ins-pc-05",
          title: "Property Inspection Image-Graph Fusion",
          industry: "Insurance",
          subIndustry: "Property & Casualty",
          summary:
            "Multi-modal fusion of inspection images, prior-claim and property graphs detects inflated or duplicate damage claims.",
          capabilities: ["multi-modal", "generative", "anomaly-detection"],
          surfaces: ["Claim review", "Underwriting"],
          kpis: [
            { label: "Inflated claims caught", delta: "+88", direction: "up" },
          ],
          dataSources: ["Images", "Claim history", "Property"],
          maturity: "Pilot",
          tags: ["property", "image", "inspection", "inflation"],
        },
      ],
    },
    {
      id: "life-health",
      name: "Life & Health",
      description: "Life, annuities, group, health and disability.",
      useCases: [
        {
          id: "ins-lh-01",
          title: "Provider-Billing Anomaly Graph",
          industry: "Insurance",
          subIndustry: "Life & Health",
          summary:
            "Streaming graph of provider, member, CPT and diagnosis edges flags billing anomalies indicative of upcoding or phantom billing.",
          capabilities: ["streaming", "anomaly-detection", "hypergraph"],
          surfaces: ["SIU", "Provider ops", "Network"],
          kpis: [
            { label: "Billing-fraud $", delta: "$9.4M", direction: "up" },
            { label: "Provider review queue", delta: "−41%", direction: "down" },
          ],
          dataSources: ["Claims", "Provider master", "Code sets"],
          maturity: "Production",
          tags: ["health", "provider", "billing-fraud", "upcoding"],
        },
        {
          id: "ins-lh-02",
          title: "Mortality-Improvement Cohort Tracking",
          industry: "Insurance",
          subIndustry: "Life & Health",
          summary:
            "Spectral clustering of policyholder cohorts tracks mortality-improvement divergence for annuity reserving.",
          capabilities: ["spectral", "dynamic-graph", "topology"],
          surfaces: ["Actuarial", "ALM", "Reserving"],
          kpis: [
            { label: "Reserve calibration error", delta: "−22%", direction: "down" },
          ],
          dataSources: ["Policyholder", "Mortality table", "Socio-econ"],
          maturity: "Pilot",
          tags: ["mortality", "annuity", "cohort", "actuarial"],
        },
        {
          id: "ins-lh-03",
          title: "Disability-Claim Malingering Topology",
          industry: "Insurance",
          subIndustry: "Life & Health",
          summary:
            "Topology of claimant, employer, provider and activity graphs surfaces inconsistent patterns warranting field investigation.",
          capabilities: ["topology", "anomaly-detection", "multi-modal"],
          surfaces: ["Disability claims", "SIU"],
          kpis: [
            { label: "Investigation hit rate", delta: "+34%", direction: "up" },
          ],
          dataSources: ["Claim", "Employer", "Provider", "Activity"],
          maturity: "Deployed",
          tags: ["disability", "malingering", "siu", "topology"],
        },
      ],
    },
    {
      id: "reinsurance",
      name: "Reinsurance & ILS",
      description: "Treaty, facultative, retrocession, capital markets.",
      useCases: [
        {
          id: "ins-ri-01",
          title: "Treaty Cumulative Risk Aggregation",
          industry: "Insurance",
          subIndustry: "Reinsurance & ILS",
          summary:
            "Hypergraph of cedant-treaty-risk-peril aggregates cumulative exposure across inwards and outwards books.",
          capabilities: ["hypergraph", "neuro-symbolic", "topology"],
          surfaces: ["Treaty underwriting", "Risk", "Capital"],
          kpis: [
            { label: "Cumulative breaches caught", delta: "+22", direction: "up" },
          ],
          dataSources: ["Treaty", "Ceded", "Peril"],
          maturity: "Production",
          tags: ["treaty", "aggregation", "reinsurance"],
        },
        {
          id: "ins-ri-02",
          title: "Retrocession Cascade Simulation",
          industry: "Insurance",
          subIndustry: "Reinsurance & ILS",
          summary:
            "Live retrocession graph simulates counterparty cascade under multi-peril events for capital planning.",
          capabilities: ["dynamic-graph", "topology", "rl-optimization"],
          surfaces: ["Capital", "Risk", "Ceded"],
          kpis: [
            { label: "Cascade scenarios / min", delta: "120", direction: "up" },
          ],
          dataSources: ["Retro", "Counterparty", "Peril"],
          maturity: "Pilot",
          tags: ["retrocession", "cascade", "capital", "simulation"],
        },
      ],
    },
    {
      id: "distribution",
      name: "Distribution & Agency",
      description: "Agents, brokers, bancassurance, affinity.",
      useCases: [
        {
          id: "ins-ds-01",
          title: "Agent-Book Network Optimisation",
          industry: "Insurance",
          subIndustry: "Distribution & Agency",
          summary:
            "Spectral embedding of agent-policy-customer graphs balances books and surfaces high-potential agents.",
          capabilities: ["spectral", "rl-optimization", "dynamic-graph"],
          surfaces: ["Agency ops", "Sales management"],
          kpis: [
            { label: "Agent retention", delta: "+12%", direction: "up" },
            { label: "Book balance score", delta: "+27%", direction: "up" },
          ],
          dataSources: ["Policy", "Agent master", "Customer"],
          maturity: "Deployed",
          tags: ["agent", "distribution", "book", "rl"],
        },
        {
          id: "ins-ds-02",
          title: "Bancassurance Lead Graph",
          industry: "Insurance",
          subIndustry: "Distribution & Agency",
          summary:
            "Multi-modal fusion of bank, customer and life-event graphs prioritises bancassurance leads for relationship managers.",
          capabilities: ["multi-modal", "spectral", "neuro-symbolic"],
          surfaces: ["Bancassurance", "RM desktop"],
          kpis: [
            { label: "Lead conversion", delta: "+19%", direction: "up" },
          ],
          dataSources: ["Bank CRM", "Life events", "Policy"],
          maturity: "Pilot",
          tags: ["bancassurance", "lead", "distribution"],
        },
      ],
    },
    {
      id: "claims",
      name: "Claims Operations",
      description: "FNOL, triage, adjustment, settlement, leakage.",
      useCases: [
        {
          id: "ins-cl-01",
          title: "FNOL Severity Triage Graph",
          industry: "Insurance",
          subIndustry: "Claims Operations",
          summary:
            "Streaming graph scores each FNOL against the live claim graph to triage severity, complexity and fraud propensity.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph"],
          surfaces: ["FNOL", "Triage", "Assignment"],
          kpis: [
            { label: "Triage accuracy", delta: "+29%", direction: "up" },
            { label: "Cycle time", delta: "−31%", direction: "down" },
          ],
          dataSources: ["FNOL", "Policy", "Claim graph"],
          maturity: "Production",
          tags: ["fnol", "triage", "claims", "real-time"],
        },
        {
          id: "ins-cl-02",
          title: "Litigation-Prediction Embedding",
          industry: "Insurance",
          subIndustry: "Claims Operations",
          summary:
            "Embedding of claim, party and counsel graphs predicts likelihood of litigation for early intervention.",
          capabilities: ["spectral", "neuro-symbolic", "generative"],
          surfaces: ["Claim ops", "Legal", "Reserving"],
          kpis: [
            { label: "Litigation predicted", delta: "+44% recall", direction: "up" },
            { label: "Legal spend", delta: "−18%", direction: "down" },
          ],
          dataSources: ["Claim", "Counsel", "Court"],
          maturity: "Deployed",
          tags: ["litigation", "claims", "legal", "prediction"],
        },
        {
          id: "ins-cl-03",
          title: "Repair-Shop Network Leakage",
          industry: "Insurance",
          subIndustry: "Claims Operations",
          summary:
            "Anomaly detection across shop-claim-adjuster-part graphs surfaces preferred-shop leakage and bid-rigging.",
          capabilities: ["anomaly-detection", "topology", "dynamic-graph"],
          surfaces: ["Auto claims", "Vendor mgmt", "SIU"],
          kpis: [
            { label: "Leakage $", delta: "−37%", direction: "down" },
          ],
          dataSources: ["Shop", "Claim", "Adjuster"],
          maturity: "Deployed",
          tags: ["repair-shop", "leakage", "vendor", "auto"],
        },
      ],
    },
  ],
};

/* =========================================================================
   MANUFACTURING
   ========================================================================= */
const MANUFACTURING: Industry = {
  id: "manufacturing",
  name: "Manufacturing & Industrial",
  code: "MFG",
  tagline: "From shop-floor sensor to multi-tier supply network.",
  description:
    "Manufacturing runs on graphs of machines, materials, suppliers, orders and operators. CIP fuses IoT, ERP and supplier data into a single live fabric — predicting failures, rebalancing supply and removing non-value-added flow.",
  accent: "#0891b2",
  icon: "Factory",
  metrics: [
    { label: "Asset Graph", value: "12M", sub: "machines + sensors + parts" },
    { label: "Unplanned Downtime", value: "−44%", sub: "predictive maintenance" },
    { label: "Inventory Turns", value: "+18%", sub: "multi-tier optimisation" },
    { label: "First-Pass Yield", value: "+5.2pp", sub: "process-graph control" },
  ],
  subIndustries: [
    {
      id: "discrete",
      name: "Discrete Manufacturing",
      description: "Automotive, electronics, industrial equipment.",
      useCases: [
        {
          id: "mfg-dm-01",
          title: "Predictive Maintenance on Asset Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Discrete Manufacturing",
          summary:
            "Streaming graph of machine, sensor, part and maintenance history predicts failures with calibrated lead time.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Maintenance", "Production", "Spare-parts"],
          kpis: [
            { label: "Unplanned downtime", delta: "−44%", direction: "down" },
            { label: "MTBF", delta: "+38%", direction: "up" },
          ],
          dataSources: ["SCADA", "CMMS", "Sensor", "MES"],
          maturity: "Production",
          tags: ["predictive-maintenance", "iot", "asset", "downtime"],
        },
        {
          id: "mfg-dm-02",
          title: "Process-Graph Quality Control",
          industry: "Manufacturing & Industrial",
          subIndustry: "Discrete Manufacturing",
          summary:
            "Topology of process-step, equipment and material graphs isolates the smallest sub-process causing yield drift.",
          capabilities: ["topology", "dynamic-graph", "neuro-symbolic"],
          surfaces: ["Quality", "Process engineering", "MES"],
          kpis: [
            { label: "First-pass yield", delta: "+5.2pp", direction: "up" },
            { label: "Root-cause time", delta: "−61%", direction: "down" },
          ],
          dataSources: ["MES", "SPC", "Equipment"],
          maturity: "Deployed",
          tags: ["quality", "yield", "process-graph", "spc"],
        },
        {
          id: "mfg-dm-03",
          title: "Multi-Tier Bill-of-Materials Risk",
          industry: "Manufacturing & Industrial",
          subIndustry: "Discrete Manufacturing",
          summary:
            "Hypergraph of supplier-plant-part-BOM exposes multi-tier concentration and geopolitical risk across the full BOM.",
          capabilities: ["hypergraph", "neuro-symbolic", "topology"],
          surfaces: ["Sourcing", "Risk", "Planning"],
          kpis: [
            { label: "Single-source parts flagged", delta: "+312", direction: "up" },
            { label: "Mitigation lead time", delta: "+24d", direction: "up" },
          ],
          dataSources: ["BOM", "Supplier", "Geo-risk"],
          maturity: "Production",
          tags: ["bom", "supply-chain", "concentration", "risk"],
        },
        {
          id: "mfg-dm-04",
          title: "Digital-Twin Synchronisation",
          industry: "Manufacturing & Industrial",
          subIndustry: "Discrete Manufacturing",
          summary:
            "Live graph keeps the digital twin in sync with the physical asset; RL suggests parameter changes that minimise drift.",
          capabilities: ["streaming", "rl-optimization", "dynamic-graph", "compression"],
          surfaces: ["Operations", "Engineering", "Maintenance"],
          kpis: [
            { label: "Twin drift", delta: "−52%", direction: "down" },
            { label: "Setpoint optimisations / day", delta: "240", direction: "up" },
          ],
          dataSources: ["IoT", "Twin model", "Historian"],
          maturity: "Pilot",
          tags: ["digital-twin", "iot", "rl", "operations"],
        },
      ],
    },
    {
      id: "process",
      name: "Process Manufacturing",
      description: "Chemicals, pharma, F&B, metals, energy.",
      useCases: [
        {
          id: "mfg-pm-01",
          title: "Batch-Recipe Deviation Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Process Manufacturing",
          summary:
            "Fuses batch, recipe, sensor and lab graphs to surface deviations before they propagate to off-spec product.",
          capabilities: ["streaming", "anomaly-detection", "dynamic-graph"],
          surfaces: ["Production", "QA", "Process eng"],
          kpis: [
            { label: "Off-spec batches", delta: "−38%", direction: "down" },
            { label: "Rework cost", delta: "−41%", direction: "down" },
          ],
          dataSources: ["Batch", "Sensor", "LIMS", "Recipe"],
          maturity: "Production",
          tags: ["batch", "process", "deviation", "quality"],
        },
        {
          id: "mfg-pm-02",
          title: "Energy-Optimisation on Utility Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Process Manufacturing",
          summary:
            "RL tunes steam, electricity and water flows across the utility graph against live price and emission signals.",
          capabilities: ["rl-optimization", "streaming", "dynamic-graph"],
          surfaces: ["Energy mgmt", "Operations", "Sustainability"],
          kpis: [
            { label: "Energy cost / unit", delta: "−14%", direction: "down" },
            { label: "Scope-1 emissions", delta: "−9%", direction: "down" },
          ],
          dataSources: ["Meter", "Price", "Emission", "Production"],
          maturity: "Deployed",
          tags: ["energy", "utility", "rl", "sustainability"],
        },
        {
          id: "mfg-pm-03",
          title: "Catalyst & Material Lifecycle Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Process Manufacturing",
          summary:
            "Hypergraph of catalyst-material-process-product edges predicts catalyst end-of-life and regeneration scheduling.",
          capabilities: ["hypergraph", "generative", "rl-optimization"],
          surfaces: ["Process eng", "Procurement", "Maintenance"],
          kpis: [
            { label: "Catalyst life extension", delta: "+12%", direction: "up" },
          ],
          dataSources: ["Catalyst log", "Process", "Lab"],
          maturity: "Pilot",
          tags: ["catalyst", "lifecycle", "process", "materials"],
        },
      ],
    },
    {
      id: "supply-chain",
      name: "Supply Chain & Logistics",
      description: "Planning, sourcing, logistics, warehousing, S&OP.",
      useCases: [
        {
          id: "mfg-sc-01",
          title: "Multi-Tier Disruption Propagation",
          industry: "Manufacturing & Industrial",
          subIndustry: "Supply Chain & Logistics",
          summary:
            "Live supplier-site-lane-part graph propagates disruption shocks through every tier to predict impacted SKUs.",
          capabilities: ["dynamic-graph", "topology", "neuro-symbolic"],
          surfaces: ["S&OP", "Sourcing", "Risk"],
          kpis: [
            { label: "Disruption lead time", delta: "+18d", direction: "up" },
            { label: "Stock-out events", delta: "−47%", direction: "down" },
          ],
          dataSources: ["Supplier", "Lane", "Part", "News"],
          maturity: "Production",
          tags: ["supply-chain", "disruption", "propagation", "s&op"],
        },
        {
          id: "mfg-sc-02",
          title: "Inventory Rebalancing RL",
          industry: "Manufacturing & Industrial",
          subIndustry: "Supply Chain & Logistics",
          summary:
            "RL agent traverses the DC-store-SKU graph to rebalance inventory against demand and capacity signals.",
          capabilities: ["rl-optimization", "streaming", "dynamic-graph"],
          surfaces: ["Planning", "Warehouse", "Allocation"],
          kpis: [
            { label: "Inventory turns", delta: "+18%", direction: "up" },
            { label: "Working capital", delta: "−12%", direction: "down" },
          ],
          dataSources: ["WMS", "Demand", "Capacity"],
          maturity: "Deployed",
          tags: ["inventory", "rebalancing", "rl", "planning"],
        },
        {
          id: "mfg-sc-03",
          title: "Lane-Risk Topology",
          industry: "Manufacturing & Industrial",
          subIndustry: "Supply Chain & Logistics",
          summary:
            "Persistent-homology analysis of lane-port-carrier-weather graphs identifies structurally fragile logistics corridors.",
          capabilities: ["topology", "streaming", "multi-modal"],
          surfaces: ["Logistics", "Risk", "Carrier mgmt"],
          kpis: [
            { label: "Fragile corridors flagged", delta: "+58", direction: "up" },
          ],
          dataSources: ["Lane", "Port", "Weather", "Carrier"],
          maturity: "Pilot",
          tags: ["logistics", "lane", "topology", "risk"],
        },
        {
          id: "mfg-sc-04",
          title: "Demand-Sensing on Channel Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Supply Chain & Logistics",
          summary:
            "Multi-modal fusion of POS, web, search and macro signals on the channel graph senses demand shifts earlier.",
          capabilities: ["multi-modal", "streaming", "spectral"],
          surfaces: ["Demand planning", "S&OP"],
          kpis: [
            { label: "Forecast MAPE", delta: "−23%", direction: "down" },
            { label: "Sense lead time", delta: "+9d", direction: "up" },
          ],
          dataSources: ["POS", "Web", "Search", "Macro"],
          maturity: "Production",
          tags: ["demand-sensing", "forecast", "channel", "s&op"],
        },
      ],
    },
    {
      id: "quality",
      name: "Quality & Reliability",
      description: "Inspection, warranty, recall, reliability engineering.",
      useCases: [
        {
          id: "mfg-qr-01",
          title: "Warranty-Claim Topology for Recall",
          industry: "Manufacturing & Industrial",
          subIndustry: "Quality & Reliability",
          summary:
            "Topology of warranty-claim-vehicle-part-dealer graphs isolates the smallest recall-worthy sub-population.",
          capabilities: ["topology", "neuro-symbolic", "dynamic-graph"],
          surfaces: ["Warranty", "Reliability", "Recall"],
          kpis: [
            { label: "Recall scope precision", delta: "+34%", direction: "up" },
            { label: "Recall cost", delta: "−27%", direction: "down" },
          ],
          dataSources: ["Warranty", "VIN", "Part", "Dealer"],
          maturity: "Production",
          tags: ["warranty", "recall", "topology", "reliability"],
        },
        {
          id: "mfg-qr-02",
          title: "Inspection-Image Defect Clustering",
          industry: "Manufacturing & Industrial",
          subIndustry: "Quality & Reliability",
          summary:
            "Multi-modal fusion of inspection images and process graphs clusters defects by root-cause neighbourhood.",
          capabilities: ["multi-modal", "spectral", "generative"],
          surfaces: ["Quality", "Process eng"],
          kpis: [
            { label: "Defect clusters caught", delta: "+42", direction: "up" },
          ],
          dataSources: ["Vision system", "Process", "SPC"],
          maturity: "Deployed",
          tags: ["inspection", "vision", "defect", "quality"],
        },
        {
          id: "mfg-qr-03",
          title: "Field-Failure Early Warning",
          industry: "Manufacturing & Industrial",
          subIndustry: "Quality & Reliability",
          summary:
            "Streaming graph of field-failure, telematics and service logs warns of emerging failure modes weeks before threshold.",
          capabilities: ["streaming", "anomaly-detection", "topology"],
          surfaces: ["Reliability", "Engineering", "Warranty"],
          kpis: [
            { label: "Field-failure lead", delta: "+26d", direction: "up" },
          ],
          dataSources: ["Telematics", "Service log", "Warranty"],
          maturity: "Pilot",
          tags: ["field-failure", "telematics", "reliability", "early-warning"],
        },
      ],
    },
    {
      id: "smart-factory",
      name: "Smart Factory & Industry 4.0",
      description: "MES, IIoT, AGVs, robotics, operator augmentation.",
      useCases: [
        {
          id: "mfg-sf-01",
          title: "AGV / Robot Fleet Coordination Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Smart Factory & Industry 4.0",
          summary:
            "RL on the live fleet-zone-task graph routes AGVs to minimise congestion and energy use.",
          capabilities: ["rl-optimization", "streaming", "dynamic-graph"],
          surfaces: ["MES", "Robotics", "Operations"],
          kpis: [
            { label: "AGV throughput", delta: "+22%", direction: "up" },
            { label: "Energy / move", delta: "−14%", direction: "down" },
          ],
          dataSources: ["AGV", "Zone", "Task", "Schedule"],
          maturity: "Pilot",
          tags: ["agv", "robotics", "rl", "industry-4.0"],
        },
        {
          id: "mfg-sf-02",
          title: "Operator-Centred Process Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Smart Factory & Industry 4.0",
          summary:
            "Hypergraph of operator-machine-task-quality surfaces best-practice patterns and propagation of variance.",
          capabilities: ["hypergraph", "spectral", "neuro-symbolic"],
          surfaces: ["Continuous improvement", "Training"],
          kpis: [
            { label: "Variance reduction", delta: "−18%", direction: "down" },
          ],
          dataSources: ["MES", "Operator log", "Quality"],
          maturity: "R&D",
          tags: ["operator", "process", "variance", "ci"],
        },
        {
          id: "mfg-sf-03",
          title: "Cyber-Physical Threat Topology",
          industry: "Manufacturing & Industrial",
          subIndustry: "Smart Factory & Industry 4.0",
          summary:
            "Topology of OT-IT-network-asset graphs flags lateral-movement anomalies indicative of cyber-physical attack.",
          capabilities: ["topology", "streaming", "anomaly-detection"],
          surfaces: ["OT security", "SOC", "Plant ops"],
          kpis: [
            { label: "OT incidents caught", delta: "+12", direction: "up" },
            { label: "Mean detect time", delta: "−72%", direction: "down" },
          ],
          dataSources: ["OT logs", "Network", "Asset"],
          maturity: "Deployed",
          tags: ["ot-security", "cyber-physical", "topology", "soc"],
        },
      ],
    },
    {
      id: "aftersales",
      name: "Aftersales & Service",
      description: "Parts, service network, contracts, field service.",
      useCases: [
        {
          id: "mfg-as-01",
          title: "Service-Contract Renewal Graph",
          industry: "Manufacturing & Industrial",
          subIndustry: "Aftersales & Service",
          summary:
            "Embedding of asset-customer-service-usage graphs predicts contract renewal and optimal service offerings.",
          capabilities: ["spectral", "rl-optimization", "dynamic-graph"],
          surfaces: ["Service sales", "Account mgmt"],
          kpis: [
            { label: "Renewal rate", delta: "+16%", direction: "up" },
            { label: "Attach rate", delta: "+11%", direction: "up" },
          ],
          dataSources: ["Asset", "Contract", "Usage"],
          maturity: "Deployed",
          tags: ["service-contract", "renewal", "aftersales"],
        },
        {
          id: "mfg-as-02",
          title: "Field-Service Dispatch Optimisation",
          industry: "Manufacturing & Industrial",
          subIndustry: "Aftersales & Service",
          summary:
            "RL on the technician-asset-part-skill graph dispatches the right tech with the right part the first time.",
          capabilities: ["rl-optimization", "streaming", "dynamic-graph"],
          surfaces: ["Field service", "Parts logistics"],
          kpis: [
            { label: "First-time-fix rate", delta: "+19%", direction: "up" },
            { label: "Truck rolls", delta: "−23%", direction: "down" },
          ],
          dataSources: ["Tech", "Asset", "Parts", "Skill"],
          maturity: "Pilot",
          tags: ["field-service", "dispatch", "rl", "first-time-fix"],
        },
      ],
    },
  ],
};

/* =========================================================================
   EXPORT
   ========================================================================= */
export const INDUSTRIES: Industry[] = [BANKING, PHARMA, FINANCE, INSURANCE, MANUFACTURING];

export const ALL_USE_CASES: UseCase[] = INDUSTRIES.flatMap((i) =>
  i.subIndustries.flatMap((s) => s.useCases)
);

export const TOTAL_USE_CASES = ALL_USE_CASES.length;
export const TOTAL_SUB_INDUSTRIES = INDUSTRIES.reduce(
  (acc, i) => acc + i.subIndustries.length,
  0
);
export const TOTAL_CAPABILITIES = CAPABILITIES.length;

export function getIndustry(id: string): Industry | undefined {
  return INDUSTRIES.find((i) => i.id === id);
}

export function getUseCase(id: string): UseCase | undefined {
  return ALL_USE_CASES.find((u) => u.id === id);
}

export function getCapability(key: CapabilityKey): Capability | undefined {
  return CAPABILITIES.find((c) => c.key === key);
}
