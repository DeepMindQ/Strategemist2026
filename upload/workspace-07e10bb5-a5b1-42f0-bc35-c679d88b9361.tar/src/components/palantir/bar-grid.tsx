"use client";

import { useEffect, useState } from "react";

interface BarGridProps {
  count?: number;
  color?: string;
  className?: string;
  /** animate random activity */
  live?: boolean;
}

/** Vertical bar grid — like an audio meter / activity indicator */
export function BarGrid({ count = 40, color = "#004c97", className, live = true }: BarGridProps) {
  const [heights, setHeights] = useState<number[]>(() =>
    // deterministic init so SSR + client match
    Array.from({ length: count }, (_, i) => 0.2 + ((i * 73) % 60) / 100)
  );

  useEffect(() => {
    if (!live) return;
    const t = setInterval(() => {
      setHeights((prev) => {
        const next = [...prev.slice(1)];
        next.push(0.15 + Math.random() * 0.75);
        return next;
      });
    }, 600);
    return () => clearInterval(t);
  }, [live]);

  return (
    <div className={`flex items-end gap-[2px] h-full ${className ?? ""}`}>
      {heights.map((h, i) => (
        <div
          key={i}
          className="flex-1 rounded-sm transition-[height] duration-500"
          style={{
            height: `${h * 100}%`,
            background: color,
            opacity: 0.35 + h * 0.65,
          }}
        />
      ))}
    </div>
  );
}
