"use client";

import { useEffect, useState } from "react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command";
import { ALL_USE_CASES, CAPABILITIES, INDUSTRIES } from "@/lib/usecase-data";
import { Search, Activity, Boxes, Layers } from "lucide-react";

interface SearchPaletteProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSelectUseCase: (id: string) => void;
  onSelectIndustry: (id: string) => void;
}

export function SearchPalette({
  open,
  onOpenChange,
  onSelectUseCase,
  onSelectIndustry,
}: SearchPaletteProps) {
  // uncontrolled input — we read value via the event target. We keep a local
  // state only for filtering; reset is handled by `key` on the dialog content
  // so we never setState inside an effect.
  const [query, setQuery] = useState("");

  const q = query.trim().toLowerCase();

  const filteredUseCases = q
    ? ALL_USE_CASES.filter(
        (u) =>
          u.title.toLowerCase().includes(q) ||
          u.summary.toLowerCase().includes(q) ||
          u.tags.some((t) => t.toLowerCase().includes(q)) ||
          u.subIndustry.toLowerCase().includes(q) ||
          u.industry.toLowerCase().includes(q) ||
          u.surfaces.some((s) => s.toLowerCase().includes(q))
      ).slice(0, 8)
    : ALL_USE_CASES.slice(0, 6);

  const filteredIndustries = q
    ? INDUSTRIES.filter(
        (i) => i.name.toLowerCase().includes(q) || i.tagline.toLowerCase().includes(q)
      )
    : INDUSTRIES;

  const filteredCapabilities = q
    ? CAPABILITIES.filter(
        (c) => c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
      )
    : CAPABILITIES.slice(0, 6);

  const handleOpenChange = (v: boolean) => {
    if (!v) setQuery("");
    onOpenChange(v);
  };

  return (
    <CommandDialog
      open={open}
      onOpenChange={handleOpenChange}
      className="max-w-2xl"
      title="CIP use-case search"
      description="Search use cases, industries and capabilities"
    >
      <CommandInput
        placeholder="Search 90+ use cases — e.g. 'fraud ring', 'cold chain', 'CAT exposure'..."
        value={query}
        onValueChange={setQuery}
      />
      <CommandList className="max-h-[60vh]">
        <CommandEmpty>No results. Try a different keyword.</CommandEmpty>

        {filteredIndustries.length > 0 && (
          <CommandGroup heading="Industries">
            {filteredIndustries.map((i) => (
              <CommandItem
                key={i.id}
                value={`ind-${i.id}-${i.name}`}
                onSelect={() => {
                  onSelectIndustry(i.id);
                  onOpenChange(false);
                }}
              >
                <Boxes className="size-4" style={{ color: i.accent }} />
                <div className="flex flex-col">
                  <span>{i.name}</span>
                  <span className="text-[10px] opacity-50">{i.tagline}</span>
                </div>
                <CommandShortcut>{i.code}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {filteredUseCases.length > 0 && (
          <CommandGroup heading="Use Cases">
            {filteredUseCases.map((u) => (
              <CommandItem
                key={u.id}
                value={`uc-${u.id}-${u.title}`}
                onSelect={() => {
                  onSelectUseCase(u.id);
                  onOpenChange(false);
                }}
              >
                <Activity className="size-4 text-[#004c97]" />
                <div className="flex flex-col min-w-0">
                  <span className="truncate">{u.title}</span>
                  <span className="text-[10px] opacity-50 truncate">
                    {u.industry} · {u.subIndustry}
                  </span>
                </div>
                <CommandShortcut className="mono">{u.id.toUpperCase()}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {filteredCapabilities.length > 0 && (
          <CommandGroup heading="Platform Capabilities">
            {filteredCapabilities.map((c) => (
              <CommandItem
                key={c.key}
                value={`cap-${c.key}-${c.name}`}
                onSelect={() => {
                  // jump to capabilities section anchor
                  onOpenChange(false);
                  if (typeof document !== "undefined") {
                    document.getElementById("capabilities")?.scrollIntoView({ behavior: "smooth" });
                  }
                }}
              >
                <Layers className="size-4 text-[#ff6c0e]" />
                <div className="flex flex-col">
                  <span>{c.name}</span>
                  <span className="text-[10px] opacity-50 truncate">{c.description}</span>
                </div>
                <CommandShortcut className="mono">{c.short}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
      <div className="px-3 py-2 border-t border-border flex items-center justify-between text-[10px] opacity-50 mono">
        <span>↵ OPEN</span>
        <span>ESC CLOSE</span>
        <span>{ALL_USE_CASES.length} USE CASES INDEXED</span>
      </div>
    </CommandDialog>
  );
}

/** Hook that wires ⌘K / Ctrl-K to open the palette */
export function useSearchShortcut(onOpen: () => void) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        onOpen();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onOpen]);
}
