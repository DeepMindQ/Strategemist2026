"use client";

import { UseCase, getCapability, CAPABILITIES } from "@/lib/usecase-data";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Sparkline } from "./sparkline";
import { RadialGauge } from "./radial-gauge";
import { NetworkGraph } from "./network-graph";
import { BarGrid } from "./bar-grid";
import { HeatMap } from "./heat-map";
import { Database, Layers, Activity, GitBranch, Target, ShieldCheck, CheckCircle2 } from "lucide-react";

interface UseCaseDetailProps {
  useCase: UseCase | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  accent: string;
}

export function UseCaseDetail({ useCase, open, onOpenChange, accent }: UseCaseDetailProps) {
  if (!useCase) return null;

  // deterministic seed from id
  const seed = useCase.id.split("").reduce((a, c) => a + c.charCodeAt(0), 0);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-2xl overflow-y-auto scroll-kefi p-0 border-border bg-white"
      >
        {/* Header band */}
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-border shadow-sm">
          <SheetHeader className="p-4 pb-3 space-y-1">
            <div className="flex items-center justify-between gap-2">
              <span className="mono text-[10px] text-slate-400 tracking-wider font-semibold">
                {useCase.id.toUpperCase()}
              </span>
              <span
                className="mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase"
                style={{ background: `${accent}15`, color: accent }}
              >
                {useCase.maturity}
              </span>
            </div>
            <SheetTitle className="text-lg leading-tight font-display font-bold text-slate-900">{useCase.title}</SheetTitle>
            <SheetDescription className="flex items-center gap-2 text-xs">
              <span className="mono px-1.5 py-0.5 rounded font-bold" style={{ background: `${accent}15`, color: accent }}>
                {useCase.industry}
              </span>
              <span className="text-slate-400">/</span>
              <span className="text-slate-600">{useCase.subIndustry}</span>
            </SheetDescription>
          </SheetHeader>
        </div>

        <div className="p-4 space-y-4">
          {/* Summary */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <Activity className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">Context</h3>
            </div>
            <p className="text-sm leading-relaxed text-slate-600">{useCase.summary}</p>
          </section>

          {/* Live graph + gauges */}
          <section className="grid grid-cols-2 gap-3">
            <div className="panel rounded-lg p-3 col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between mb-1">
                <span className="mono text-[10px] text-slate-500 uppercase font-semibold">Live Subgraph</span>
                <span className="mono text-[10px] font-bold" style={{ color: accent }}>
                  {useCase.capabilities.length} caps
                </span>
              </div>
              <NetworkGraph
                nodes={26}
                width={320}
                height={180}
                accent={accent}
                seed={seed}
                className="w-full h-[180px]"
              />
            </div>
            <div className="panel rounded-lg p-3 col-span-2 sm:col-span-1 flex items-center justify-around">
              <RadialGauge
                value={72 + (seed % 18)}
                label="Precision"
                color={accent}
                size={108}
              />
              <RadialGauge
                value={58 + (seed % 24)}
                label="Coverage"
                color="#7c3aed"
                size={108}
              />
            </div>
          </section>

          {/* KPIs */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <Target className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">Service KPIs</h3>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {useCase.kpis.map((k, i) => {
                const isUp = k.direction === "up";
                return (
                  <div key={i} className="panel rounded-lg p-3">
                    <div className="mono text-[9px] text-slate-500 uppercase truncate font-semibold">{k.label}</div>
                    <div
                      className="mono text-base font-bold mt-1"
                      style={{ color: isUp ? "#16a34a" : "#dc2626" }}
                    >
                      {k.delta}
                    </div>
                    <Sparkline
                      width={120}
                      height={24}
                      color={isUp ? "#16a34a" : "#dc2626"}
                      className="w-full mt-1.5"
                    />
                  </div>
                );
              })}
            </div>
          </section>

          {/* Capabilities used */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <Layers className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">
                Platform Capabilities Engaged
              </h3>
            </div>
            <div className="space-y-1.5">
              {useCase.capabilities.map((key) => {
                const cap = getCapability(key);
                if (!cap) return null;
                return (
                  <div
                    key={key}
                    className="panel rounded-lg p-3 flex items-start gap-3 hover:shadow-md transition"
                  >
                    <span
                      className="mono text-[10px] px-1.5 py-0.5 rounded font-bold shrink-0 mt-0.5"
                      style={{ background: `${accent}15`, color: accent }}
                    >
                      {cap.short}
                    </span>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 font-display">{cap.name}</div>
                      <div className="text-[11px] text-slate-600 leading-snug mt-0.5">
                        {cap.description}
                      </div>
                    </div>
                    <CheckCircle2 className="size-3.5 text-emerald-500 shrink-0 mt-0.5" />
                  </div>
                );
              })}
            </div>
          </section>

          {/* Implementation surfaces */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <GitBranch className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">
                Implementation Surfaces
              </h3>
            </div>
            <div className="panel rounded-lg p-3">
              <p className="text-[11px] text-slate-500 mb-2.5 leading-snug">
                CIP plugs into the following systems within the {useCase.subIndustry} domain:
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {useCase.surfaces.map((s, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 text-[11px] bg-slate-50 rounded-md px-2 py-1.5 border border-slate-100"
                  >
                    <span
                      className="w-1.5 h-1.5 rounded-full shrink-0"
                      style={{ background: accent }}
                    />
                    <span className="truncate text-slate-700 font-medium">{s}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Data sources */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <Database className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">Fused Data Sources</h3>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {useCase.dataSources.map((d, i) => (
                <span
                  key={i}
                  className="mono text-[10px] px-2 py-1 rounded-md border border-slate-200 bg-slate-50 text-slate-700 font-semibold"
                >
                  {d}
                </span>
              ))}
            </div>
          </section>

          {/* Activity heat map */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">
                Detection Activity · 24h x 7d
              </h3>
            </div>
            <div className="panel rounded-lg p-3">
              <HeatMap
                rows={7}
                cols={24}
                color={accent}
                seed={seed}
                xLabels={["00", "04", "08", "12", "16", "20"]}
              />
              <div className="flex items-center justify-between mt-2">
                <span className="mono text-[10px] text-slate-500 font-semibold">LOW</span>
                <div className="flex gap-[2px]">
                  {[0.2, 0.4, 0.6, 0.8, 1].map((o) => (
                    <span
                      key={o}
                      className="w-3 h-3 rounded-sm"
                      style={{ background: accent, opacity: 0.12 + o * 0.88 }}
                    />
                  ))}
                </div>
                <span className="mono text-[10px] text-slate-500 font-semibold">HIGH</span>
              </div>
            </div>
          </section>

          {/* Tags */}
          <section>
            <div className="flex items-center gap-2 mb-2">
              <Activity className="size-3.5" style={{ color: accent }} />
              <h3 className="text-xs uppercase tracking-wider font-bold text-slate-700 font-display">Index Tags</h3>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {useCase.tags.map((t) => (
                <span
                  key={t}
                  className="text-[10px] px-2 py-0.5 rounded-full border border-slate-200 bg-slate-50 text-slate-600 font-medium"
                >
                  #{t}
                </span>
              ))}
            </div>
          </section>

          {/* CTA */}
          <section className="panel-raised rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div
                className="w-9 h-9 rounded-md flex items-center justify-center shrink-0"
                style={{ background: `${accent}18`, color: accent }}
              >
                <BarGrid count={8} color={accent} className="w-full h-4" live={false} />
              </div>
              <div className="flex-1">
                <div className="text-sm font-bold text-slate-900 font-display">Engage KefiTech on this use case</div>
                <div className="text-[11px] text-slate-600 mt-0.5">
                  A 90-minute working session maps your data estate to a CIP deployment plan for{" "}
                  <span className="font-semibold text-slate-800">{useCase.title}</span>.
                </div>
                <button
                  className="mt-3 w-full text-xs font-bold py-2 rounded-md transition shadow-sm hover:shadow-md"
                  style={{ background: accent, color: "#ffffff" }}
                >
                  Request Briefing →
                </button>
              </div>
            </div>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
