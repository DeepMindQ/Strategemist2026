"use client";

import { ReactNode } from "react";

interface StatTileProps {
  label: string;
  value: string;
  sub?: string;
  accent?: string;
  right?: ReactNode;
  className?: string;
}

export function StatTile({ label, value, sub, accent = "#004c97", right, className }: StatTileProps) {
  return (
    <div className={`relative panel rounded-lg p-3 overflow-hidden hover:shadow-md transition-shadow ${className ?? ""}`}>
      <div
        className="absolute left-0 top-0 bottom-0 w-[3px]"
        style={{ background: accent }}
      />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-wider opacity-60 mono truncate font-semibold">{label}</div>
          <div className="mono text-2xl font-bold mt-1 font-display" style={{ color: accent }}>
            {value}
          </div>
          {sub && <div className="text-[10px] opacity-60 mt-0.5 truncate">{sub}</div>}
        </div>
        {right}
      </div>
    </div>
  );
}
