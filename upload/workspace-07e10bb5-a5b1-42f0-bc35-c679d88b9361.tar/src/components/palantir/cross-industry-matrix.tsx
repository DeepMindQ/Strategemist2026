"use client";

import { INDUSTRIES, CAPABILITIES, ALL_USE_CASES } from "@/lib/usecase-data";
import { Panel } from "./panel";
import * as Icons from "lucide-react";
import { motion } from "framer-motion";

interface CrossIndustryMatrixProps {
  onPick: (industryId: string) => void;
}

/** Matrix: industries (rows) x capabilities (cols), cell = use-case count */
export function CrossIndustryMatrix({ onPick }: CrossIndustryMatrixProps) {
  const cell = (industryId: string, capKey: string) =>
    ALL_USE_CASES.filter(
      (u) => u.industry === INDUSTRIES.find((i) => i.id === industryId)?.name && u.capabilities.includes(capKey as any)
    ).length;

  const max = Math.max(
    ...INDUSTRIES.flatMap((i) =>
      CAPABILITIES.map((c) => cell(i.id, c.key))
    )
  );

  return (
    <section id="matrix" className="space-y-4">
      <div className="flex items-end justify-between flex-wrap gap-2">
        <div>
          <div className="mono text-[10px] tracking-[0.3em] text-[#004c97] mb-1 font-semibold">
            INDEX // CROSS-INDUSTRY
          </div>
          <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            One platform. Every industry. Searchable.
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            The matrix below is the index. Click any industry row to jump to its
            use-case explorer.
          </p>
        </div>
        <div className="mono text-[10px] text-slate-500 font-semibold">
          {INDUSTRIES.length}×{CAPABILITIES.length} = {INDUSTRIES.length * CAPABILITIES.length} CELLS
        </div>
      </div>

      <Panel accent="#004c97" className="overflow-x-auto" bodyClassName="p-2">
        <div className="min-w-[760px]">
          {/* header row */}
          <div
            className="grid gap-1 mb-1"
            style={{ gridTemplateColumns: `180px repeat(${CAPABILITIES.length}, 1fr) 70px` }}
          >
            <div />
            {CAPABILITIES.map((c) => (
              <div
                key={c.key}
                className="mono text-[9px] text-center text-slate-500 py-1 font-bold"
                title={c.name}
              >
                {c.short}
              </div>
            ))}
            <div className="mono text-[9px] text-center text-slate-500 font-bold">Σ UC</div>
          </div>

          {/* industry rows */}
          {INDUSTRIES.map((ind, ri) => {
            const Icon = (Icons as Record<string, Icons.LucideIcon>)[ind.icon] ?? Icons.Boxes;
            const rowTotal = ind.subIndustries.reduce((a, s) => a + s.useCases.length, 0);
            return (
              <motion.button
                key={ind.id}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: ri * 0.05 }}
                onClick={() => onPick(ind.id)}
                className="grid gap-1 mb-1 group w-full text-left hover:bg-slate-50 rounded-md transition px-1 py-1"
                style={{ gridTemplateColumns: `180px repeat(${CAPABILITIES.length}, 1fr) 70px` }}
              >
                <div className="flex items-center gap-2 px-1">
                  <div
                    className="w-6 h-6 rounded-md flex items-center justify-center shrink-0"
                    style={{ background: `${ind.accent}18`, color: ind.accent }}
                  >
                    <Icon className="size-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold truncate text-slate-900 font-display">{ind.name}</div>
                    <div className="mono text-[9px] text-slate-400 font-semibold">{ind.code}</div>
                  </div>
                </div>

                {CAPABILITIES.map((c) => {
                  const n = cell(ind.id, c.key);
                  const intensity = max > 0 ? n / max : 0;
                  return (
                    <div
                      key={c.key}
                      className="aspect-square rounded-md flex items-center justify-center mono text-[10px] transition group-hover:scale-110"
                      style={{
                        background: n > 0 ? `${ind.accent}${Math.round(intensity * 200 + 30).toString(16).padStart(2, "0")}` : "#f1f5f9",
                        color: n > 0 ? "#0f172a" : "#cbd5e1",
                        fontWeight: n > 0 ? 700 : 400,
                      }}
                      title={`${ind.name} × ${c.name}: ${n} use case${n === 1 ? "" : "s"}`}
                    >
                      {n > 0 ? n : "·"}
                    </div>
                  );
                })}

                <div className="flex items-center justify-center mono text-sm font-bold" style={{ color: ind.accent }}>
                  {rowTotal}
                </div>
              </motion.button>
            );
          })}

          {/* legend */}
          <div className="flex items-center justify-between mt-3 px-1">
            <div className="flex items-center gap-2 mono text-[9px] text-slate-500 font-semibold">
              <span>LOW</span>
              <div className="flex gap-0.5">
                {[0.1, 0.3, 0.5, 0.7, 1].map((o) => (
                  <span
                    key={o}
                    className="w-4 h-4 rounded-sm"
                    style={{ background: "#004c97", opacity: o }}
                  />
                ))}
              </div>
              <span>HIGH</span>
            </div>
            <span className="mono text-[9px] text-slate-500 font-semibold">
              click any row to open industry explorer
            </span>
          </div>
        </div>
      </Panel>
    </section>
  );
}
