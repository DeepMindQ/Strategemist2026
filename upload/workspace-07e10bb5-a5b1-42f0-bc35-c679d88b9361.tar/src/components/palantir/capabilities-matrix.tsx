"use client";

import { CAPABILITIES, INDUSTRIES, ALL_USE_CASES } from "@/lib/usecase-data";
import { Panel } from "./panel";
import { motion } from "framer-motion";
import * as Icons from "lucide-react";
import { NetworkGraph } from "./network-graph";

const CAP_ICONS: Record<string, Icons.LucideIcon> = {
  "dynamic-graph": Icons.GitBranch,
  "anomaly-detection": Icons.AlertTriangle,
  "multi-modal": Icons.Layers,
  hypergraph: Icons.Share2,
  "quantum-embedding": Icons.Atom,
  streaming: Icons.Radio,
  generative: Icons.Sparkles,
  "rl-optimization": Icons.Target,
  topology: Icons.Hexagon,
  spectral: Icons.Waves,
  "neuro-symbolic": Icons.BrainCircuit,
  compression: Icons.Box,
};

export function CapabilitiesMatrix() {
  return (
    <section id="capabilities" className="space-y-4">
      <div className="flex items-end justify-between flex-wrap gap-2">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="mono text-[10px] tracking-[0.3em] text-[#004c97] font-semibold">
              PLATFORM // CAPABILITIES
            </span>
          </div>
          <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            Twelve capabilities. One contextual fabric.
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Every KefiTech CIP engagement composes these service modules. None of the
            language below is claim text — it is the productised surface of the
            underlying contextual-intelligence research.
          </p>
        </div>
        <div className="mono text-[10px] text-slate-500 font-semibold">
          {CAPABILITIES.length} CAPABILITIES · {INDUSTRIES.length} INDUSTRIES
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-4">
        {/* Capability cards */}
        <div className="lg:col-span-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {CAPABILITIES.map((c, i) => {
            const Icon = CAP_ICONS[c.key] ?? Icons.Box;
            const usageCount = ALL_USE_CASES.filter((u) =>
              u.capabilities.includes(c.key)
            ).length;
            // alternate accent colors per capability for visual variety
            const palette = ["#004c97", "#ff6c0e", "#0d9488", "#7c3aed", "#0891b2"];
            const accent = palette[i % palette.length];
            return (
              <motion.div
                key={c.key}
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
              >
                <Panel accent={accent} className="h-full">
                  <div className="flex items-start justify-between mb-2">
                    <div
                      className="w-9 h-9 rounded-md flex items-center justify-center"
                      style={{ background: `${accent}15`, color: accent }}
                    >
                      <Icon className="size-5" />
                    </div>
                    <span
                      className="mono text-[10px] px-1.5 py-0.5 rounded font-bold"
                      style={{ background: `${accent}15`, color: accent }}
                    >
                      {c.short}
                    </span>
                  </div>
                  <div className="text-sm font-bold text-slate-900 font-display">{c.name}</div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                    {c.description}
                  </p>
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100">
                    <span className="mono text-[10px] text-slate-500 font-semibold">
                      used in <span style={{ color: accent }} className="font-bold">{usageCount}</span> use cases
                    </span>
                    <div className="flex gap-0.5">
                      {Array.from({ length: 12 }).map((_, j) => (
                        <span
                          key={j}
                          className="w-1 h-3 rounded-sm"
                          style={{
                            background: accent,
                            opacity: j < Math.ceil((usageCount / ALL_USE_CASES.length) * 12) ? 0.85 : 0.12,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </Panel>
              </motion.div>
            );
          })}
        </div>

        {/* Side graph */}
        <div className="lg:col-span-4 space-y-4">
          <Panel title="Capability Graph" code="CAP.NET" accent="#7c3aed">
            <NetworkGraph
              nodes={32}
              width={320}
              height={220}
              accent="#7c3aed"
              seed={42}
              className="w-full h-[220px]"
            />
          </Panel>
          <Panel title="Stack Composition" code="STACK" accent="#7c3aed">
            <div className="space-y-2.5">
              {[
                { layer: "Ingestion", v: 92, c: "#004c97" },
                { layer: "Graph Engine", v: 88, c: "#0d9488" },
                { layer: "Embedding / Quantum", v: 76, c: "#7c3aed" },
                { layer: "Reasoning / Neuro-Symbolic", v: 71, c: "#ff6c0e" },
                { layer: "Action / RL", v: 64, c: "#0891b2" },
              ].map((l) => (
                <div key={l.layer}>
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-slate-700 font-semibold">{l.layer}</span>
                    <span className="mono text-slate-500 font-bold">{l.v}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${l.v}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1 }}
                      className="h-full rounded-full"
                      style={{ background: l.c }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </section>
  );
}
