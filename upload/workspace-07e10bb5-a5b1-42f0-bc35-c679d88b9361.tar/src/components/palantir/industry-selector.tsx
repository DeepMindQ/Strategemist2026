"use client";

import { INDUSTRIES } from "@/lib/usecase-data";
import * as Icons from "lucide-react";
import { motion } from "framer-motion";

interface IndustrySelectorProps {
  active: string;
  onChange: (id: string) => void;
}

export function IndustrySelector({ active, onChange }: IndustrySelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
      {INDUSTRIES.map((ind, i) => {
        const Icon = (Icons as Record<string, Icons.LucideIcon>)[ind.icon] ?? Icons.Boxes;
        const isActive = active === ind.id;
        return (
          <motion.button
            key={ind.id}
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            onClick={() => onChange(ind.id)}
            className={`relative panel rounded-lg p-4 text-left transition-all group overflow-hidden ${
              isActive ? "panel-raised" : "hover:shadow-md"
            }`}
            style={isActive ? { boxShadow: `0 0 0 2px ${ind.accent}, 0 8px 24px ${ind.accent}25` } : undefined}
          >
            {/* accent bar */}
            <span
              className="absolute left-0 top-0 bottom-0 w-[3px] transition-all"
              style={{ background: ind.accent, opacity: isActive ? 1 : 0.4 }}
            />
            <div className="flex items-center justify-between mb-2">
              <div
                className="w-9 h-9 rounded-md flex items-center justify-center"
                style={{ background: `${ind.accent}15`, color: ind.accent }}
              >
                <Icon className="size-5" />
              </div>
              <span
                className="mono text-[10px] px-1.5 py-0.5 rounded font-bold"
                style={{ background: `${ind.accent}15`, color: ind.accent }}
              >
                {ind.code}
              </span>
            </div>
            <div className="text-sm font-bold leading-tight text-slate-900 font-display">{ind.name}</div>
            <div className="mono text-[10px] text-slate-500 mt-1 line-clamp-2 leading-snug">
              {ind.tagline}
            </div>
            {isActive && (
              <motion.span
                layoutId="ind-active-dot"
                className="absolute bottom-2 right-2 w-1.5 h-1.5 rounded-full pulse-dot"
                style={{ background: ind.accent }}
              />
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
