"use client";

interface RadarChartProps {
  axes: { label: string; value: number }[]; // value 0-100
  color?: string;
  size?: number;
  className?: string;
}

export function RadarChart({ axes, color = "#004c97", size = 240, className }: RadarChartProps) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 30;
  const n = axes.length;
  const angle = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;

  const rings = [0.25, 0.5, 0.75, 1];

  const pointAt = (i: number, val: number) => {
    const a = angle(i);
    return [cx + Math.cos(a) * r * val, cy + Math.sin(a) * r * val];
  };

  const polygon = axes
    .map((ax, i) => {
      const [x, y] = pointAt(i, ax.value / 100);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const gid = `radar-${color.replace("#", "")}-${size}`;

  return (
    <svg viewBox={`0 0 ${size} ${size}`} className={className} role="img" aria-label="Capability radar">
      <defs>
        <radialGradient id={gid} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0.10" />
        </radialGradient>
      </defs>
      {/* rings */}
      {rings.map((ring, i) => (
        <polygon
          key={i}
          points={axes
            .map((_, j) => {
              const [x, y] = pointAt(j, ring);
              return `${x.toFixed(1)},${y.toFixed(1)}`;
            })
            .join(" ")}
          fill={i === rings.length - 1 ? `url(#${gid})` : "none"}
          stroke="#0f172a"
          strokeOpacity="0.12"
          strokeWidth="0.8"
        />
      ))}
      {/* spokes */}
      {axes.map((_, i) => {
        const [x, y] = pointAt(i, 1);
        return (
          <line
            key={i}
            x1={cx}
            y1={cy}
            x2={x}
            y2={y}
            stroke="#0f172a"
            strokeOpacity="0.10"
            strokeWidth="0.8"
          />
        );
      })}
      {/* data polygon */}
      <polygon points={polygon} fill={color} fillOpacity="0.22" stroke={color} strokeWidth="1.8" />
      {/* data points */}
      {axes.map((ax, i) => {
        const [x, y] = pointAt(i, ax.value / 100);
        return (
          <g key={i}>
            <circle cx={x} cy={y} r="3.5" fill={color} />
            <circle cx={x} cy={y} r="1.5" fill="#ffffff" />
          </g>
        );
      })}
      {/* labels */}
      {axes.map((ax, i) => {
        const [x, y] = pointAt(i, 1.2);
        return (
          <text
            key={i}
            x={x}
            y={y}
            fontSize="9"
            fill="#0f172a"
            fillOpacity="0.75"
            textAnchor="middle"
            dominantBaseline="middle"
            className="mono"
            fontWeight={700}
          >
            {ax.label}
          </text>
        );
      })}
    </svg>
  );
}
