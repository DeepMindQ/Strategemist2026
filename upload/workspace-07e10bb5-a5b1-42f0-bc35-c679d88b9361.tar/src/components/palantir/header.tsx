"use client";

import { Activity, Search, Command } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface HeaderProps {
  onOpenSearch: () => void;
  onJumpTo: (id: string) => void;
}

export function Header({ onOpenSearch, onJumpTo }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-white/85 border-b border-border shadow-sm">
      <div className="max-w-[1600px] mx-auto px-4 lg:px-6 h-14 flex items-center gap-4">
        {/* Logo / brand */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex items-center gap-2.5 group"
        >
          <div className="relative">
            <div
              className="w-7 h-7 rounded-md flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #004c97 0%, #ff6c0e 100%)" }}
            >
              <Activity className="size-4 text-white" strokeWidth={2.5} />
            </div>
            <div className="absolute -inset-0.5 rounded-md bg-[#004c97]/25 blur-sm -z-10 group-hover:bg-[#ff6c0e]/30 transition" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-sm font-bold tracking-wide font-display">
              Kefi<span className="text-[#ff6c0e]">Tech</span>{" "}
              <span className="text-[#004c97]">CIP</span>
            </span>
            <span className="mono text-[9px] text-slate-500 tracking-widest">
              CONTEXTUAL INTELLIGENCE PLATFORM
            </span>
          </div>
        </button>

        {/* Nav */}
        <nav className="hidden md:flex items-center gap-1 ml-4">
          {[
            { id: "overview", label: "Overview" },
            { id: "industries", label: "Industries" },
            { id: "use-cases", label: "Use Cases" },
            { id: "capabilities", label: "Capabilities" },
            { id: "architecture", label: "Architecture" },
          ].map((n) => (
            <button
              key={n.id}
              onClick={() => onJumpTo(n.id)}
              className="text-xs px-3 py-1.5 rounded-md hover:bg-[#004c97]/8 transition uppercase tracking-wider font-semibold text-slate-600 hover:text-[#004c97]"
            >
              {n.label}
            </button>
          ))}
        </nav>

        <div className="flex-1" />

        {/* Search trigger */}
        <Button
          variant="outline"
          size="sm"
          onClick={onOpenSearch}
          className="hidden sm:flex gap-2 w-56 lg:w-72 justify-between bg-white border-border hover:border-[#004c97]/40"
        >
          <span className="flex items-center gap-2 text-slate-500">
            <Search className="size-3.5" />
            <span className="text-xs">Search use cases...</span>
          </span>
          <kbd className="mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 border border-border flex items-center gap-0.5 text-slate-600">
            <Command className="size-2.5" />K
          </kbd>
        </Button>

        <Button
          size="icon"
          variant="outline"
          onClick={onOpenSearch}
          className="sm:hidden bg-white"
          aria-label="Search"
        >
          <Search className="size-4" />
        </Button>

        {/* Status pill */}
        <TooltipProvider delayDuration={200}>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="hidden lg:flex items-center gap-1.5 px-2 py-1 rounded-md border border-border bg-white">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-dot" />
                <span className="mono text-[10px] text-slate-600 font-semibold">SYS NOMINAL</span>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom">All subsystems operational</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <Button
          size="sm"
          className="bg-[#004c97] text-white hover:bg-[#003a73] hidden sm:flex shadow-sm"
        >
          Request Briefing
        </Button>
      </div>
    </header>
  );
}
