"use client";

import { useEffect, useState } from "react";

interface RadialGaugeProps {
  value: number; // 0-100
  label?: string;
  sublabel?: string;
  color?: string;
  size?: number;
  className?: string;
}

export function RadialGauge({
  value,
  label,
  sublabel,
  color = "#004c97",
  size = 120,
  className,
}: RadialGaugeProps) {
  const [v, setV] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setV(value), 120);
    return () => clearTimeout(t);
  }, [value]);

  const r = size / 2 - 10;
  const c = 2 * Math.PI * r;
  // 3/4 arc
  const arc = c * 0.75;
  const offset = arc - (v / 100) * arc;

  return (
    <div className={`relative inline-flex flex-col items-center ${className ?? ""}`}>
      <svg width={size} height={size} className="-rotate-[135deg]">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#0f172a"
          strokeOpacity="0.10"
          strokeWidth="7"
          strokeDasharray={`${arc} ${c}`}
          strokeLinecap="round"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeDasharray={`${arc} ${c}`}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="mono text-xl font-bold font-display" style={{ color }}>
          {Math.round(v)}
          <span className="text-xs opacity-60">%</span>
        </span>
        {label && <span className="text-[10px] uppercase tracking-wider opacity-60 mt-0.5 font-semibold">{label}</span>}
        {sublabel && <span className="text-[9px] opacity-50 mono">{sublabel}</span>}
      </div>
    </div>
  );
}
