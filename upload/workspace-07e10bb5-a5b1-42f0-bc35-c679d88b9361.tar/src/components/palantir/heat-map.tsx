"use client";

interface HeatMapProps {
  rows?: number;
  cols?: number;
  color?: string;
  className?: string;
  /** cell labels for x-axis */
  xLabels?: string[];
  yLabels?: string[];
  seed?: number;
}

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function HeatMap({
  rows = 7,
  cols = 24,
  color = "#004c97",
  className,
  xLabels,
  yLabels,
  seed = 11,
}: HeatMapProps) {
  const rng = mulberry32(seed);
  const cells: number[][] = [];
  for (let i = 0; i < rows; i++) {
    const row: number[] = [];
    for (let j = 0; j < cols; j++) {
      // create some structure: gaussian-ish bands
      const base = 0.15 + 0.4 * Math.exp(-((i - rows / 2) ** 2) / 6) * Math.exp(-((j - cols / 2) ** 2) / 60);
      row.push(Math.min(1, base + rng() * 0.35));
    }
    cells.push(row);
  }

  return (
    <div className={className}>
      <div className="flex">
        {yLabels && <div className="w-12 shrink-0" />}
        <div className="grid gap-[2px] flex-1" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
          {Array.from({ length: rows }).map((_, i) =>
            Array.from({ length: cols }).map((_, j) => {
              const v = cells[i][j];
              return (
                <div
                  key={`${i}-${j}`}
                  className="aspect-square rounded-[2px] transition-transform hover:scale-125 hover:z-10 relative"
                  style={{
                    background: color,
                    opacity: 0.12 + v * 0.88,
                  }}
                  title={`r${i} c${j}: ${(v * 100).toFixed(0)}%`}
                />
              );
            })
          )}
        </div>
      </div>
      {xLabels && (
        <div className="flex mt-1">
          <div className="w-12 shrink-0" />
          <div className="grid flex-1" style={{ gridTemplateColumns: `repeat(${xLabels.length}, 1fr)` }}>
            {xLabels.map((l) => (
              <span key={l} className="mono text-[9px] opacity-50 text-center font-semibold">
                {l}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
