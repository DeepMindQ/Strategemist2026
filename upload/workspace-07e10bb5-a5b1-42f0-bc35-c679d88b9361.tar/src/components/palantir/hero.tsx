"use client";

import { motion } from "framer-motion";
import { NetworkGraph } from "./network-graph";
import { Sparkline } from "./sparkline";
import { BarGrid } from "./bar-grid";
import { ALL_USE_CASES, CAPABILITIES, INDUSTRIES, TOTAL_SUB_INDUSTRIES } from "@/lib/usecase-data";
import { ArrowRight, Cpu, GitBranch, Layers, Zap } from "lucide-react";

interface HeroProps {
  onJumpTo: (id: string) => void;
  onOpenSearch: () => void;
}

export function Hero({ onJumpTo, onOpenSearch }: HeroProps) {
  return (
    <section id="overview" className="relative overflow-hidden border-b border-border">
      {/* background grid */}
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#004c97]/5 via-transparent to-transparent" />
      {/* decorative orange orb */}
      <div
        className="absolute -top-20 -right-20 w-96 h-96 rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, #ff6c0e 0%, transparent 70%)" }}
      />

      <div className="max-w-[1600px] mx-auto px-4 lg:px-6 py-10 lg:py-16 relative">
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Left — title */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              suppressHydrationWarning
            >
              <div className="flex items-center gap-2 mb-5">
                <span
                  className="mono text-[10px] tracking-[0.3em] text-[#004c97] px-2 py-1 rounded-md border border-[#004c97]/25 bg-[#004c97]/5 font-semibold"
                >
                  CIP // CONTEXTUAL INTELLIGENCE
                </span>
                <span className="mono text-[10px] tracking-widest text-slate-400 font-semibold">
                  BUILD 4.2.0 · GNN CORE
                </span>
              </div>

              <h1 className="font-display text-4xl lg:text-6xl font-bold tracking-tight leading-[1.05] text-slate-900">
                Contextual intelligence for{" "}
                <span className="text-grad-blue">every graph your business runs on.</span>
              </h1>

              <p className="mt-5 text-base lg:text-lg text-slate-600 max-w-2xl leading-relaxed">
                KefiTech CIP is a graph-neural-network service fabric that fuses your
                transactions, entities, signals and documents into one living graph — and
                reasons over it in real time. Explore{" "}
                <span className="text-[#004c97] mono font-semibold">{ALL_USE_CASES.length} production use cases</span>{" "}
                across{" "}
                <span className="text-[#004c97] mono font-semibold">{INDUSTRIES.length} industries</span> and{" "}
                <span className="text-[#004c97] mono font-semibold">{TOTAL_SUB_INDUSTRIES} sub-domains</span>.
              </p>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenSearch}
                  className="inline-flex items-center gap-2 bg-[#004c97] text-white px-5 py-2.5 rounded-md font-semibold text-sm hover:bg-[#003a73] transition shadow-md hover:shadow-lg"
                >
                  Search the use-case index
                  <ArrowRight className="size-4" />
                </button>
                <button
                  onClick={() => onJumpTo("industries")}
                  className="inline-flex items-center gap-2 border border-[#ff6c0e] text-[#ff6c0e] px-5 py-2.5 rounded-md font-semibold text-sm hover:bg-[#ff6c0e] hover:text-white transition"
                >
                  Browse by industry
                </button>
              </div>

              {/* feature chips */}
              <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  { icon: Zap, label: "Real-time streaming", v: "42ms p99", color: "#004c97" },
                  { icon: GitBranch, label: "Hypergraph modeling", v: "Multi-entity", color: "#ff6c0e" },
                  { icon: Cpu, label: "Quantum-inspired", v: "Hilbert embed", color: "#0d9488" },
                  { icon: Layers, label: "Neuro-symbolic", v: "Interpretable", color: "#7c3aed" },
                ].map((f) => (
                  <div
                    key={f.label}
                    className="panel rounded-lg p-3 flex items-center gap-3 hover:shadow-md transition-shadow"
                  >
                    <div
                      className="w-9 h-9 rounded-md flex items-center justify-center shrink-0"
                      style={{ background: `${f.color}15`, color: f.color }}
                    >
                      <f.icon className="size-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold truncate text-slate-800">{f.label}</div>
                      <div className="mono text-[10px] text-slate-500 truncate">{f.v}</div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right — live visualizer */}
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="panel-raised rounded-lg p-3 grid-bg"
              suppressHydrationWarning
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#004c97] pulse-dot" />
                  <span className="mono text-[10px] tracking-widest text-slate-600 font-semibold">
                    LIVE · CONTEXT GRAPH
                  </span>
                </div>
                <span className="mono text-[10px] text-slate-400 font-semibold">REGION: GLOBAL</span>
              </div>
              <NetworkGraph nodes={34} edgeDensity={1.5} width={520} height={260} accent="#004c97" className="w-full h-[260px]" />

              <div className="grid grid-cols-3 gap-2 mt-3">
                <div className="panel rounded-md p-2">
                  <div className="mono text-[9px] text-slate-500 uppercase font-semibold">Throughput</div>
                  <div className="mono text-sm font-bold text-[#004c97]">1.42M/s</div>
                  <Sparkline width={120} height={28} color="#004c97" />
                </div>
                <div className="panel rounded-md p-2">
                  <div className="mono text-[9px] text-slate-500 uppercase font-semibold">Anomaly</div>
                  <div className="mono text-sm font-bold text-[#ff6c0e]">0.34%</div>
                  <Sparkline width={120} height={28} color="#ff6c0e" />
                </div>
                <div className="panel rounded-md p-2 h-[78px]">
                  <div className="mono text-[9px] text-slate-500 uppercase font-semibold mb-1">Activity</div>
                  <BarGrid count={20} color="#0d9488" className="h-8" />
                </div>
              </div>
            </motion.div>

            {/* quick stats */}
            <div className="grid grid-cols-4 gap-2 mt-3">
              {[
                { k: "INDUSTRIES", v: String(INDUSTRIES.length), c: "#004c97" },
                { k: "SUB-DOMAINS", v: String(TOTAL_SUB_INDUSTRIES), c: "#ff6c0e" },
                { k: "USE CASES", v: String(ALL_USE_CASES.length), c: "#0d9488" },
                { k: "CAPABILITIES", v: String(CAPABILITIES.length), c: "#7c3aed" },
              ].map((s) => (
                <div key={s.k} className="panel rounded-md p-2.5 text-center hover:shadow-md transition-shadow">
                  <div className="mono text-2xl font-bold font-display" style={{ color: s.c }}>
                    {s.v}
                  </div>
                  <div className="mono text-[9px] text-slate-500 tracking-widest mt-0.5 font-semibold">{s.k}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
