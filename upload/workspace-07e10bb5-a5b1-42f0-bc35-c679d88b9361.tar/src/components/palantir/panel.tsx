"use client";

import { ReactNode } from "react";

interface PanelProps {
  title?: string;
  code?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  accent?: string;
  glow?: boolean;
  scan?: boolean;
}

/** KefiTech-style panel — white card with corner brackets + mono header */
export function Panel({
  title,
  code,
  right,
  children,
  className = "",
  bodyClassName = "",
  accent = "#004c97",
  glow = false,
  scan = false,
}: PanelProps) {
  return (
    <div
      className={`relative panel rounded-lg ${glow ? "panel-raised" : ""} ${scan ? "scan-line" : ""} ${className}`}
    >
      {/* corner brackets */}
      <span className="absolute left-0 top-0 w-2.5 h-2.5 border-l-2 border-t-2 rounded-tl-lg" style={{ borderColor: accent }} />
      <span className="absolute right-0 top-0 w-2.5 h-2.5 border-r-2 border-t-2 rounded-tr-lg" style={{ borderColor: accent }} />
      <span className="absolute left-0 bottom-0 w-2.5 h-2.5 border-l-2 border-b-2 rounded-bl-lg" style={{ borderColor: accent }} />
      <span className="absolute right-0 bottom-0 w-2.5 h-2.5 border-r-2 border-b-2 rounded-br-lg" style={{ borderColor: accent }} />

      {(title || code || right) && (
        <div className="flex items-center justify-between px-3.5 py-2 border-b border-border bg-slate-50/60 rounded-t-lg">
          <div className="flex items-center gap-2 min-w-0">
            {code && (
              <span
                className="mono text-[10px] px-1.5 py-0.5 rounded font-semibold"
                style={{ background: `${accent}15`, color: accent, letterSpacing: "0.1em" }}
              >
                {code}
              </span>
            )}
            {title && (
              <span className="text-xs font-semibold tracking-wide truncate uppercase font-display" style={{ color: "#0f172a" }}>
                {title}
              </span>
            )}
          </div>
          {right && <div className="flex items-center gap-2 shrink-0">{right}</div>}
        </div>
      )}
      <div className={`p-3.5 ${bodyClassName}`}>{children}</div>
    </div>
  );
}
