"use client";

import { Panel } from "./panel";
import { NetworkGraph } from "./network-graph";
import { Sparkline } from "./sparkline";
import { motion } from "framer-motion";
import {
  Database,
  Workflow,
  Brain,
  ShieldCheck,
  ArrowRight,
  Cpu,
  GitBranch,
  Layers,
  Gauge,
  Boxes,
} from "lucide-react";

const LAYERS = [
  {
    code: "L1",
    name: "Data Estate Ingestion",
    icon: Database,
    accent: "#004c97",
    desc: "Deterministic streaming engine ingests transactions, events, documents and signals via micro-batched, conflict-resolved connectors.",
    items: ["Kafka / Pulsar", "Change-data-capture", "Document AI", "IoT / SCADA", "API & file"],
  },
  {
    code: "L2",
    name: "Context Graph Fabric",
    icon: GitBranch,
    accent: "#0d9488",
    desc: "Multi-modal fusion unifies heterogeneous inputs into a single evolving graph — supporting pairwise and hypergraph relations.",
    items: ["Dynamic edge rewire", "Hypergraph modeling", "Entity resolution", "Temporal versioning"],
  },
  {
    code: "L3",
    name: "Embedding & Spectral Core",
    icon: Cpu,
    accent: "#7c3aed",
    desc: "Quantum-inspired embedding maps substructures into high-dimensional spaces; spectral and topological analytics isolate task-relevant features.",
    items: ["Hilbert-style embed", "Spectral decomposition", "Persistent homology", "Fractal compression"],
  },
  {
    code: "L4",
    name: "Reasoning & Decision",
    icon: Brain,
    accent: "#ff6c0e",
    desc: "Neuro-symbolic reasoning couples embeddings with domain rules; RL tunes the graph toward task-specific objectives.",
    items: ["Neuro-symbolic rules", "RL optimization", "Anomaly scoring", "Generative reconstruction"],
  },
  {
    code: "L5",
    name: "Action & Governance",
    icon: ShieldCheck,
    accent: "#0891b2",
    desc: "Deterministic outputs flow back to operational systems with full lineage, audit and human-in-the-loop controls.",
    items: ["Decision API", "Case management", "Lineage & audit", "Policy & explainability"],
  },
];

export function Architecture() {
  return (
    <section id="architecture" className="space-y-4">
      <div className="flex items-end justify-between flex-wrap gap-2">
        <div>
          <div className="mono text-[10px] tracking-[0.3em] text-[#004c97] mb-1 font-semibold">
            SYSTEM // ARCHITECTURE
          </div>
          <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            Five layers from raw signal to governed action.
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            KefiTech CIP is deployed as a service. Each layer exposes stable APIs so
            client teams can plug in at the depth that matches their maturity.
          </p>
        </div>
        <div className="mono text-[10px] text-slate-500 font-semibold">5 LAYERS · END-TO-END</div>
      </div>

      <div className="grid lg:grid-cols-12 gap-4">
        {/* Layer stack */}
        <div className="lg:col-span-8 space-y-2">
          {LAYERS.map((l, i) => (
            <motion.div
              key={l.code}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
            >
              <Panel accent={l.accent} className="overflow-hidden">
                <div className="flex items-stretch gap-3">
                  {/* left rail */}
                  <div
                    className="w-14 shrink-0 flex flex-col items-center justify-center rounded-md"
                    style={{ background: `${l.accent}12` }}
                  >
                    <span className="mono text-[10px] text-slate-500 font-bold">{l.code}</span>
                    <l.icon className="size-5 mt-1" style={{ color: l.accent }} />
                  </div>

                  <div className="flex-1 py-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-bold text-slate-900 font-display">{l.name}</h3>
                      <span
                        className="mono text-[9px] px-1.5 py-0.5 rounded font-bold"
                        style={{ background: `${l.accent}15`, color: l.accent }}
                      >
                        {l.items.length} modules
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 mt-1 leading-snug">{l.desc}</p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {l.items.map((it) => (
                        <span
                          key={it}
                          className="mono text-[10px] px-1.5 py-0.5 rounded-md border border-slate-200 bg-slate-50 text-slate-700 font-semibold"
                        >
                          {it}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* right mini-viz */}
                  <div className="hidden md:flex w-32 shrink-0 items-center justify-center border-l border-slate-100">
                    <Sparkline
                      width={110}
                      height={36}
                      color={l.accent}
                      data={Array.from({ length: 20 }, (_, j) => 40 + Math.sin((i + j) / 2) * 18 + ((i * 37 + j * 11) % 9))}
                    />
                  </div>
                </div>
              </Panel>
            </motion.div>
          ))}
        </div>

        {/* Side: live graph + flow */}
        <div className="lg:col-span-4 space-y-4">
          <Panel title="Live Reasoning Graph" code="SYS.NET" accent="#004c97">
            <NetworkGraph
              nodes={30}
              width={320}
              height={200}
              accent="#004c97"
              seed={99}
              className="w-full h-[200px]"
            />
            <div className="grid grid-cols-3 gap-2 mt-2">
              {[
                { k: "OPS/S", v: "1.42M", c: "#004c97" },
                { k: "P99", v: "42ms", c: "#0d9488" },
                { k: "NODES", v: "1.4B", c: "#7c3aed" },
              ].map((s) => (
                <div key={s.k} className="panel rounded-md p-2 text-center">
                  <div className="mono text-sm font-bold" style={{ color: s.c }}>
                    {s.v}
                  </div>
                  <div className="mono text-[9px] text-slate-500 font-semibold">{s.k}</div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Decision Flow" code="FLOW" accent="#7c3aed">
            <div className="space-y-2">
              {[
                { icon: Database, label: "Ingest", c: "#004c97" },
                { icon: Layers, label: "Fuse", c: "#0d9488" },
                { icon: Cpu, label: "Embed", c: "#7c3aed" },
                { icon: Brain, label: "Reason", c: "#ff6c0e" },
                { icon: Gauge, label: "Act", c: "#0891b2" },
              ].map((s, i, arr) => (
                <div key={s.label} className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded-md flex items-center justify-center shrink-0"
                    style={{ background: `${s.c}15`, color: s.c }}
                  >
                    <s.icon className="size-3.5" />
                  </div>
                  <span className="text-xs flex-1 text-slate-700 font-semibold">{s.label}</span>
                  {i < arr.length - 1 && <ArrowRight className="size-3 text-slate-300" />}
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>

      {/* Deployment models */}
      <Panel title="Deployment Models" code="DEPLOY" accent="#004c97">
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            {
              icon: Boxes,
              name: "Sandbox",
              desc: "Synthetic data, full capability surface. 2-week standing engagement to validate fit.",
              tag: "0 DATA EGRESS",
            },
            {
              icon: Workflow,
              name: "Co-deployed",
              desc: "KefiTech CIP runs alongside client estate with read-only ingestion. Use-case SLAs in 90 days.",
              tag: "READ-ONLY",
            },
            {
              icon: ShieldCheck,
              name: "Embedded",
              desc: "CIP operates inside client security perimeter with decision APIs feeding ops systems.",
              tag: "FULL DECISION LOOP",
            },
          ].map((d) => (
            <div key={d.name} className="panel rounded-lg p-3 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-md bg-[#004c97]/15 text-[#004c97] flex items-center justify-center">
                  <d.icon className="size-4" />
                </div>
                <span className="mono text-[9px] px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 font-bold">
                  {d.tag}
                </span>
              </div>
              <div className="text-sm font-bold text-slate-900 font-display">{d.name}</div>
              <p className="text-[11px] text-slate-600 mt-1 leading-snug">{d.desc}</p>
            </div>
          ))}
        </div>
      </Panel>
    </section>
  );
}
