"use client";

import { useEffect, useState } from "react";

interface TickerItem {
  label: string;
  value: string;
  delta?: string;
  dir?: "up" | "down";
}

interface TickerProps {
  items?: TickerItem[];
  className?: string;
}

const DEFAULT_ITEMS: TickerItem[] = [
  { label: "CIP.THRU", value: "1.42M ops/s", delta: "+4.1%", dir: "up" },
  { label: "BNK.ATO", value: "12 alerts", delta: "+3", dir: "up" },
  { label: "PHR.AE.SIG", value: "7 signals", delta: "−2", dir: "down" },
  { label: "FIN.ALPHA", value: "+38bps", delta: "+2bps", dir: "up" },
  { label: "INS.FRAUD", value: "$1.4M", delta: "+$0.2M", dir: "up" },
  { label: "MFG.DT", value: "−44%", delta: "+1.1pp", dir: "up" },
  { label: "GRAPH.NODES", value: "1.4B", delta: "+12M", dir: "up" },
  { label: "GRAPH.EDGES", value: "18.7B", delta: "+0.4B", dir: "up" },
  { label: "DETECT.P99", value: "42ms", delta: "−3ms", dir: "down" },
  { label: "RL.STEPS", value: "8.2M", delta: "+0.3M", dir: "up" },
  { label: "ANOM.PRECISION", value: "0.91", delta: "+0.02", dir: "up" },
  { label: "FRACTAL.COMP", value: "3.8x", delta: "+0.1x", dir: "up" },
];

export function Ticker({ items = DEFAULT_ITEMS, className }: TickerProps) {
  const [, setSeed] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setSeed((s) => s + 1), 4000);
    return () => clearInterval(t);
  }, []);

  // duplicate items for seamless loop
  const doubled = [...items, ...items];

  return (
    <div className={`relative overflow-hidden border-y border-border bg-[#004c97] text-white ${className ?? ""}`}>
      <div className="flex ticker-track whitespace-nowrap py-1.5">
        {doubled.map((item, i) => {
          const isUp = item.dir !== "down";
          return (
            <div key={i} className="flex items-center gap-2 px-4 mono text-xs">
              <span className="opacity-70">{item.label}</span>
              <span className="font-semibold">{item.value}</span>
              {item.delta && (
                <span style={{ color: isUp ? "#86efac" : "#fca5a5" }}>
                  {isUp ? "▲" : "▼"} {item.delta}
                </span>
              )}
              <span className="opacity-30">|</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
