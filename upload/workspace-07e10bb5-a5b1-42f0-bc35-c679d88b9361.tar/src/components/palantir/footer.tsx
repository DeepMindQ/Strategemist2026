"use client";

import { Activity, ArrowUpRight } from "lucide-react";

export function Footer() {
  // Static year — avoids SSR/CSR hydration mismatch and the
  // set-state-in-effect lint rule. Update annually.
  const year = 2025;

  return (
    <footer className="mt-auto border-t border-border bg-slate-50">
      <div className="max-w-[1600px] mx-auto px-4 lg:px-6 py-8">
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-2.5">
              <div
                className="w-7 h-7 rounded-md flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, #004c97 0%, #ff6c0e 100%)" }}
              >
                <Activity className="size-4 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-sm font-bold tracking-wide font-display">
                  Kefi<span className="text-[#ff6c0e]">Tech</span>{" "}
                  <span className="text-[#004c97]">CIP</span>
                </span>
                <span className="mono text-[9px] text-slate-500 tracking-widest font-semibold">
                  CONTEXTUAL INTELLIGENCE PLATFORM
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-3 max-w-md leading-relaxed">
              KefiTech CIP is the service surface of contextual-intelligence
              research built on graph neural networks. The use cases indexed on
              this page describe applications of the service and do not disclose
              any patent claims.
            </p>
            <div className="flex items-center gap-2 mt-4">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-dot" />
              <span className="mono text-[10px] text-slate-600 font-semibold">ALL SUBSYSTEMS NOMINAL</span>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              {
                title: "Industries",
                links: ["Banking", "Pharma & Life Sciences", "Finance & Capital Markets", "Insurance", "Manufacturing & Industrial"],
              },
              {
                title: "Platform",
                links: ["Dynamic Graph Engine", "Anomaly Detection", "Hypergraph Modeling", "Neuro-Symbolic Reasoning", "RL Optimization"],
              },
              {
                title: "Engage",
                links: ["Request Briefing", "Sandbox", "Co-deployment", "Embedded", "Partner Program"],
              },
              {
                title: "Company",
                links: ["About KefiTech", "Research", "Responsible AI", "Careers", "Contact"],
              },
            ].map((col) => (
              <div key={col.title}>
                <div className="mono text-[10px] uppercase tracking-wider text-[#004c97] mb-2 font-bold">
                  {col.title}
                </div>
                <ul className="space-y-1.5">
                  {col.links.map((l) => (
                    <li key={l}>
                      <a
                        href="#"
                        className="text-xs text-slate-600 hover:text-[#ff6c0e] transition flex items-center gap-1 group font-medium"
                      >
                        {l}
                        <ArrowUpRight className="size-2.5 opacity-0 group-hover:opacity-60 transition" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mt-8 pt-4 border-t border-slate-200">
          <div className="mono text-[10px] text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-1 font-semibold">
            <span>© {year} KEFITECH</span>
            <span className="opacity-50">·</span>
            <span>KEFI TECH — SOFTWARE SERVICE COMPANY</span>
            <span className="opacity-50">·</span>
            <span>ALL RIGHTS RESERVED</span>
          </div>
          <div className="mono text-[10px] text-slate-400 flex items-center gap-3 font-semibold">
            <span>BUILD 4.2.0</span>
            <span className="opacity-50">·</span>
            <span>GNN CORE</span>
            <span className="opacity-50">·</span>
            <span className="cursor-blink text-[#ff6c0e]">_</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
