"use client";

import { useEffect, useMemo, useState } from "react";

interface Node {
  id: string;
  x: number;
  y: number;
  r: number;
  /** cluster color index */
  c: number;
  /** label */
  label?: string;
  /** pulse */
  pulse?: boolean;
}

interface Edge {
  s: number;
  t: number;
  w?: number;
}

interface NetworkGraphProps {
  nodes?: number;
  edgeDensity?: number;
  width?: number;
  height?: number;
  accent?: string;
  className?: string;
  animated?: boolean;
  showLabels?: boolean;
  seed?: number;
}

const PALETTE = ["#004c97", "#ff6c0e", "#0d9488", "#7c3aed", "#0891b2"];

/** Deterministic PRNG so the graph is stable across renders */
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function NetworkGraph({
  nodes: nodeCount = 28,
  edgeDensity = 1.4,
  width = 480,
  height = 280,
  accent,
  className,
  animated = true,
  showLabels = false,
  seed = 7,
}: NetworkGraphProps) {
  const data = useMemo(() => {
    const r = mulberry32(seed);
    const ns: Node[] = [];
    // cluster seeds
    const clusterCount = 4;
    const centers = Array.from({ length: clusterCount }, () => ({
      x: 0.15 + r() * 0.7,
      y: 0.15 + r() * 0.7,
    }));
    for (let i = 0; i < nodeCount; i++) {
      const cIdx = Math.floor(r() * clusterCount);
      const cx = centers[cIdx].x;
      const cy = centers[cIdx].y;
      const angle = r() * Math.PI * 2;
      const rad = r() * 0.18;
      ns.push({
        id: `n${i}`,
        x: (cx + Math.cos(angle) * rad) * width,
        y: (cy + Math.sin(angle) * rad) * height,
        r: 3.2 + r() * 4.6,
        c: cIdx,
        label: showLabels ? `N${i}` : undefined,
        pulse: r() > 0.82,
      });
    }
    // edges within + across
    const es: Edge[] = [];
    for (let i = 0; i < nodeCount; i++) {
      const same = ns
        .map((n, j) => ({ j, d: Math.hypot(n.x - ns[i].x, n.y - ns[i].y), c: n.c }))
        .filter((o) => o.j !== i && o.c === ns[i].c)
        .sort((a, b) => a.d - b.d)
        .slice(0, 2 + Math.floor(r() * 2));
      same.forEach((o) => es.push({ s: i, t: o.j, w: 1 - o.d / (width * 0.4) }));
      if (r() < 0.2) {
        const j = Math.floor(r() * nodeCount);
        if (j !== i && ns[j].c !== ns[i].c) es.push({ s: i, t: j, w: 0.25 });
      }
    }
    return { ns, es };
  }, [nodeCount, edgeDensity, width, height, seed]);

  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (!animated) return;
    const i = setInterval(() => setTick((t) => t + 1), 1800);
    return () => clearInterval(i);
  }, [animated]);

  // pick a few "live" edges to highlight (flowing dashes)
  const liveEdges = useMemo(() => {
    if (!data.es.length) return new Set<number>();
    const count = Math.max(2, Math.floor(data.es.length * 0.08));
    const set = new Set<number>();
    let s = tick * 7;
    for (let k = 0; k < count; k++) {
      s = (s * 1664525 + 1013904223) >>> 0;
      set.add(s % data.es.length);
    }
    return set;
  }, [tick, data.es]);

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="Network graph visualization"
    >
      <defs>
        {PALETTE.map((c, i) => (
          <radialGradient key={i} id={`ng-node-${i}-${accent?.replace("#", "") ?? "k"}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={(accent ?? PALETTE[i])} stopOpacity="1" />
            <stop offset="100%" stopColor={(accent ?? PALETTE[i])} stopOpacity="0.25" />
          </radialGradient>
        ))}
        <filter id="ng-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* edges */}
      {data.es.map((e, i) => {
        const a = data.ns[e.s];
        const b = data.ns[e.t];
        const live = liveEdges.has(i) && animated;
        const color = accent ?? PALETTE[a.c % PALETTE.length];
        return (
          <line
            key={`e-${i}`}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke={live ? color : "#004c97"}
            strokeOpacity={live ? 0.9 : 0.10 + (e.w ?? 0) * 0.18}
            strokeWidth={live ? 1.8 : 0.7}
            className={live ? "dash-flow" : undefined}
          />
        );
      })}

      {/* nodes */}
      {data.ns.map((n, i) => {
        const color = accent ?? PALETTE[n.c % PALETTE.length];
        const isPulse = n.pulse && animated;
        return (
          <g key={`n-${i}`}>
            {isPulse && (
              <>
                <circle
                  cx={n.x}
                  cy={n.y}
                  r={n.r + 2}
                  fill="none"
                  stroke={color}
                  strokeOpacity="0.5"
                  strokeWidth="1"
                  className="node-pulse-ring"
                  style={{ transformOrigin: `${n.x}px ${n.y}px` }}
                />
                <circle
                  cx={n.x}
                  cy={n.y}
                  r={n.r + 6}
                  fill="none"
                  stroke={color}
                  strokeOpacity="0.25"
                  strokeWidth="0.8"
                  className="pulse-dot"
                  style={{ transformOrigin: `${n.x}px ${n.y}px` }}
                />
              </>
            )}
            <circle
              cx={n.x}
              cy={n.y}
              r={n.r}
              fill={color}
              fillOpacity="0.92"
              filter="url(#ng-glow)"
            />
            <circle
              cx={n.x}
              cy={n.y}
              r={n.r * 0.45}
              fill="#ffffff"
              fillOpacity="0.7"
            />
            {n.label && (
              <text
                x={n.x + n.r + 3}
                y={n.y + 3}
                fontSize="9"
                fill="#0f172a"
                fillOpacity="0.6"
                fontFamily="ui-monospace, monospace"
                fontWeight={600}
              >
                {n.label}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}
