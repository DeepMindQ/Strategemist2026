"use client";

import { useEffect, useState } from "react";

interface SparklineProps {
  data?: number[];
  width?: number;
  height?: number;
  color?: string;
  fill?: boolean;
  className?: string;
  /** show a marker dot at the latest point */
  marker?: boolean;
  /** show area gradient fill */
  area?: boolean;
}

// deterministic initial series so server + client match
function initialSeries() {
  return Array.from({ length: 28 }, (_, i) => 50 + Math.sin(i / 2) * 14 + ((i * 37) % 17) * 0.6);
}

export function Sparkline({
  data: dataProp,
  width = 120,
  height = 32,
  color = "#004c97",
  fill = true,
  className,
  marker = true,
  area = true,
}: SparklineProps) {
  // Start with deterministic data so SSR + client match. Then upgrade to
  // animated random walk after mount.
  const [data, setData] = useState<number[]>(() => dataProp ?? initialSeries());

  useEffect(() => {
    if (dataProp) return;
    const t = setInterval(() => {
      setData((prev) => {
        const next = [...prev.slice(1)];
        const last = prev[prev.length - 1];
        next.push(Math.max(10, Math.min(95, last + (Math.random() - 0.45) * 14)));
        return next;
      });
    }, 1200);
    return () => clearInterval(t);
  }, [dataProp]);

  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const stepX = width / (data.length - 1);

  const pts = data.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 6) - 3;
    return [x, y];
  });

  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const areaPath = `${path} L${width},${height} L0,${height} Z`;
  const gid = `sp-${color.replace("#", "")}-${Math.round(width)}-${Math.round(height)}`;
  const last = pts[pts.length - 1];

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      preserveAspectRatio="none"
      aria-hidden
    >
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && area && <path d={areaPath} fill={`url(#${gid})`} />}
      <path
        d={path}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {marker && (
        <>
          <circle cx={last[0]} cy={last[1]} r="3.2" fill={color} className="pulse-dot" />
          <circle cx={last[0]} cy={last[1]} r="1.4" fill="#ffffff" />
        </>
      )}
    </svg>
  );
}
