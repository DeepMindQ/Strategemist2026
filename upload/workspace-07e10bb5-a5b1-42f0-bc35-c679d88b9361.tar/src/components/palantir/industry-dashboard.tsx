"use client";

import { useMemo, useState } from "react";
import { CAPABILITIES, Industry, UseCase } from "@/lib/usecase-data";
import * as Icons from "lucide-react";
import { motion } from "framer-motion";
import { Panel } from "./panel";
import { StatTile } from "./stat-tile";
import { Sparkline } from "./sparkline";
import { NetworkGraph } from "./network-graph";
import { HeatMap } from "./heat-map";
import { BarGrid } from "./bar-grid";
import { RadarChart } from "./radar-chart";
import { UseCaseCard } from "./use-case-card";
import { Search, SlidersHorizontal, X, ChevronDown } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CAP_LOOKUP: Record<string, (typeof CAPABILITIES)[number]> = Object.fromEntries(
  CAPABILITIES.map((c) => [c.key, c])
);

interface IndustryDashboardProps {
  industry: Industry;
  onOpenUseCase: (uc: UseCase) => void;
}

export function IndustryDashboard({ industry, onOpenUseCase }: IndustryDashboardProps) {
  const [query, setQuery] = useState("");
  const [maturity, setMaturity] = useState<string>("all");
  const [capFilter, setCapFilter] = useState<string>("all");
  const Icon = (Icons as Record<string, Icons.LucideIcon>)[industry.icon] ?? Icons.Boxes;

  const allUseCases = useMemo(
    () => industry.subIndustries.flatMap((s) => s.useCases),
    [industry]
  );

  const filteredBySub = useMemo(() => {
    const q = query.trim().toLowerCase();
    return industry.subIndustries.map((s) => ({
      ...s,
      useCases: s.useCases.filter((u) => {
        if (q) {
          const hay = `${u.title} ${u.summary} ${u.tags.join(" ")} ${u.surfaces.join(" ")} ${u.subIndustry} ${u.industry}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        if (maturity !== "all" && u.maturity !== maturity) return false;
        if (capFilter !== "all" && !u.capabilities.includes(capFilter as any)) return false;
        return true;
      }),
    }));
  }, [industry, query, maturity, capFilter]);

  const shownCount = filteredBySub.reduce((a, s) => a + s.useCases.length, 0);

  // capability usage stats
  const capUsage = useMemo(() => {
    const map = new Map<string, number>();
    allUseCases.forEach((u) => u.capabilities.forEach((c) => map.set(c, (map.get(c) ?? 0) + 1)));
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [allUseCases]);

  // radar axes — top 6 capabilities by usage
  const radarAxes = capUsage
    .slice(0, 6)
    .map(([key, count]) => {
      const cap = CAP_LOOKUP[key];
      return {
        label: cap?.short ?? key.slice(0, 3).toUpperCase(),
        value: Math.min(100, count * 18 + 20),
      };
    });

  return (
    <div className="space-y-4">
      {/* Industry banner */}
      <Panel accent={industry.accent} glow scan>
        <div className="grid lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7">
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-md flex items-center justify-center shrink-0"
                style={{ background: `${industry.accent}18`, color: industry.accent }}
              >
                <Icon className="size-7" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
                    {industry.name}
                  </h2>
                  <span
                    className="mono text-[10px] px-1.5 py-0.5 rounded font-bold"
                    style={{ background: `${industry.accent}15`, color: industry.accent }}
                  >
                    {industry.code}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mt-1 font-medium">{industry.tagline}</p>
                <p className="text-[13px] text-slate-600 mt-3 leading-relaxed max-w-2xl">
                  {industry.description}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-5">
              {industry.metrics.map((m, i) => (
                <StatTile
                  key={m.label}
                  label={m.label}
                  value={m.value}
                  sub={m.sub}
                  accent={industry.accent}
                  right={<Sparkline width={60} height={22} color={industry.accent} className="opacity-60" />}
                />
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 grid grid-cols-2 gap-3">
            <Panel title="Sub-Domain Network" code={industry.code} accent={industry.accent} className="col-span-2" bodyClassName="p-2">
              <NetworkGraph
                nodes={industry.subIndustries.length * 5 + 4}
                width={420}
                height={180}
                accent={industry.accent}
                seed={industry.id.charCodeAt(0)}
                className="w-full h-[180px]"
              />
            </Panel>
            <Panel title="Capability Mix" code="CAP" accent={industry.accent} bodyClassName="p-2 flex items-center justify-center">
              {radarAxes.length > 0 && (
                <RadarChart axes={radarAxes} color={industry.accent} size={180} className="w-full h-[140px]" />
              )}
            </Panel>
            <Panel title="Activity" code="ACT" accent={industry.accent} bodyClassName="p-2">
              <BarGrid count={18} color={industry.accent} className="h-[120px]" />
            </Panel>
          </div>
        </div>
      </Panel>

      {/* Sub-domain rail */}
      <Panel
        title="Sub-Domain Coverage"
        code={`${industry.code}.SUB`}
        accent={industry.accent}
        right={
          <span className="mono text-[10px] opacity-50">
            {industry.subIndustries.length} sub-domains · {allUseCases.length} use cases
          </span>
        }
      >
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {industry.subIndustries.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
              className="panel rounded-md p-3 hover:shadow-md transition group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold leading-tight text-slate-900">{s.name}</span>
                <span
                  className="mono text-[10px] px-1 py-0.5 rounded font-bold"
                  style={{ background: `${industry.accent}15`, color: industry.accent }}
                >
                  {s.useCases.length} UC
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-snug line-clamp-2">{s.description}</p>
              {/* mini activity */}
              <div className="mt-2 h-6">
                <BarGrid
                  count={s.useCases.length * 2 + 8}
                  color={industry.accent}
                  live={false}
                  className="h-full"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </Panel>

      {/* USE CASE INDEX / SEARCH */}
      <div id="use-cases" />
      <Panel
        title="Use-Case Index"
        code={`${industry.code}.IDX`}
        accent={industry.accent}
        right={
          <span className="mono text-[10px] opacity-50">
            showing {shownCount} / {allUseCases.length}
          </span>
        }
      >
        {/* Filter bar */}
        <div className="flex flex-col lg:flex-row gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`Filter ${industry.name.toLowerCase()} use cases — e.g. '${allUseCases[0]?.tags[0] ?? "fraud"}'...`}
              className="w-full pl-8 pr-8 py-2 bg-white border border-slate-200 rounded-md text-xs outline-none focus:border-[#004c97] focus:ring-2 focus:ring-[#004c97]/15 transition mono text-slate-700"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100"
              >
                <X className="size-3" />
              </button>
            )}
          </div>
          <Select value={maturity} onValueChange={setMaturity}>
            <SelectTrigger className="w-full lg:w-36 h-8 text-xs bg-card border-border">
              <SlidersHorizontal className="size-3 mr-1 opacity-50" />
              <SelectValue placeholder="Maturity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All maturities</SelectItem>
              <SelectItem value="Production">Production</SelectItem>
              <SelectItem value="Deployed">Deployed</SelectItem>
              <SelectItem value="Pilot">Pilot</SelectItem>
              <SelectItem value="R&D">R&D</SelectItem>
            </SelectContent>
          </Select>
          <Select value={capFilter} onValueChange={setCapFilter}>
            <SelectTrigger className="w-full lg:w-40 h-8 text-xs bg-card border-border">
              <SelectValue placeholder="Capability" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All capabilities</SelectItem>
              {capUsage.map(([key, count]) => {
                const cap = CAP_LOOKUP[key];
                return (
                  <SelectItem key={key} value={key}>
                    {cap?.short ?? key} ({count})
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {/* active filter badges */}
        {(query || maturity !== "all" || capFilter !== "all") && (
          <div className="flex flex-wrap gap-1.5 mb-3">
            {query && (
              <Badge variant="outline" className="text-[10px] gap-1 bg-card">
                q: "{query}"
                <button onClick={() => setQuery("")}>
                  <X className="size-2.5" />
                </button>
              </Badge>
            )}
            {maturity !== "all" && (
              <Badge variant="outline" className="text-[10px] gap-1 bg-card">
                {maturity}
                <button onClick={() => setMaturity("all")}>
                  <X className="size-2.5" />
                </button>
              </Badge>
            )}
            {capFilter !== "all" && (
              <Badge variant="outline" className="text-[10px] gap-1 bg-card">
                cap: {CAP_LOOKUP[capFilter]?.short ?? capFilter}
                <button onClick={() => setCapFilter("all")}>
                  <X className="size-2.5" />
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Grouped by sub-industry accordion */}
        <Accordion type="multiple" defaultValue={industry.subIndustries.map((s) => s.id)} className="space-y-2">
          {filteredBySub.map((s) => (
            <AccordionItem
              key={s.id}
              value={s.id}
              className="border border-slate-200 rounded-md overflow-hidden bg-white hover:shadow-sm transition"
            >
              <AccordionTrigger className="px-3 py-2.5 hover:no-underline hover:bg-slate-50 group">
                <div className="flex items-center gap-3 flex-1 text-left">
                  <span
                    className="w-1 h-8 rounded-sm shrink-0"
                    style={{ background: industry.accent }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 font-display">{s.name}</span>
                      <span
                        className="mono text-[10px] px-1 py-0.5 rounded font-bold"
                        style={{ background: `${industry.accent}15`, color: industry.accent }}
                      >
                        {s.useCases.length} UC
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 truncate">{s.description}</p>
                  </div>
                </div>
                <ChevronDown className="size-4 text-slate-400 group-data-[state=open]:rotate-180 transition shrink-0 ml-2" />
              </AccordionTrigger>
              <AccordionContent className="px-3 pb-3 pt-1">
                {s.useCases.length === 0 ? (
                  <div className="text-xs text-slate-500 py-6 text-center mono">
                    No use cases match the current filter.
                  </div>
                ) : (
                  <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-2">
                    {s.useCases.map((uc) => (
                      <UseCaseCard
                        key={uc.id}
                        uc={uc}
                        accent={industry.accent}
                        onClick={() => onOpenUseCase(uc)}
                      />
                    ))}
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        {shownCount === 0 && (
          <div className="py-10 text-center">
            <div className="mono text-xs opacity-50">No use cases match.</div>
            <button
              onClick={() => {
                setQuery("");
                setMaturity("all");
                setCapFilter("all");
              }}
              className="mt-3 text-xs text-[#004c97] hover:underline font-semibold"
            >
              clear filters
            </button>
          </div>
        )}
      </Panel>

      {/* Capability usage panel */}
      <Panel
        title="Capability Utilisation"
        code={`${industry.code}.CAP`}
        accent={industry.accent}
      >
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {capUsage.map(([key, count]) => {
            const cap = CAP_LOOKUP[key];
            if (!cap) return null;
            const pct = Math.min(100, (count / allUseCases.length) * 100 * 1.6);
            return (
              <div key={key} className="panel rounded-md p-3 hover:shadow-md transition">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 font-display">{cap.name}</span>
                  <span
                    className="mono text-[10px] px-1 py-0.5 rounded font-bold"
                    style={{ background: `${industry.accent}15`, color: industry.accent }}
                  >
                    {cap.short}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${pct}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8 }}
                      className="h-full rounded-full"
                      style={{ background: industry.accent }}
                    />
                  </div>
                  <span className="mono text-[10px] text-slate-500 w-8 text-right font-bold">{count}×</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1.5 line-clamp-1">{cap.description}</div>
              </div>
            );
          })}
        </div>
      </Panel>

      {/* Heat map footer */}
      <Panel
        title="Detection Density · 24h x 7d"
        code={`${industry.code}.HMAP`}
        accent={industry.accent}
      >
        <HeatMap
          rows={7}
          cols={24}
          color={industry.accent}
          seed={industry.id.charCodeAt(0) * 3}
          xLabels={["00", "04", "08", "12", "16", "20"]}
        />
      </Panel>
    </div>
  );
}
