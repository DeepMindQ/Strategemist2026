"use client";

import { UseCase, getCapability } from "@/lib/usecase-data";
import { ArrowUpRight, ArrowDownRight, ChevronRight } from "lucide-react";

interface UseCaseCardProps {
  uc: UseCase;
  accent: string;
  onClick: () => void;
  /** highlight flag */
  highlight?: boolean;
}

export function UseCaseCard({ uc, accent, onClick, highlight }: UseCaseCardProps) {
  return (
    <button
      onClick={onClick}
      className={`relative panel rounded-lg p-3.5 text-left transition-all group w-full hover:shadow-lg hover:-translate-y-0.5 ${
        highlight ? "panel-raised" : ""
      }`}
      style={highlight ? { boxShadow: `0 0 0 2px ${accent}40` } : undefined}
    >
      {/* top row: id + maturity */}
      <div className="flex items-center justify-between mb-2">
        <span className="mono text-[10px] text-slate-400 tracking-wider font-semibold">{uc.id.toUpperCase()}</span>
        <span
          className="mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase"
          style={{
            background: `${accent}15`,
            color: accent,
          }}
        >
          {uc.maturity}
        </span>
      </div>

      <h4 className="text-sm font-bold leading-snug group-hover:text-[#004c97] transition font-display text-slate-900">
        {uc.title}
      </h4>

      <p className="text-[11px] text-slate-600 mt-1.5 leading-snug line-clamp-3">{uc.summary}</p>

      {/* capability chips */}
      <div className="flex flex-wrap gap-1 mt-2.5">
        {uc.capabilities.slice(0, 3).map((c) => {
          const cap = getCapability(c);
          return (
            <span
              key={c}
              className="mono text-[9px] px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-600 font-semibold"
            >
              {cap?.short}
            </span>
          );
        })}
        {uc.capabilities.length > 3 && (
          <span className="mono text-[9px] px-1 py-0.5 text-slate-400 font-semibold">+{uc.capabilities.length - 3}</span>
        )}
      </div>

      {/* KPI deltas */}
      <div className="grid grid-cols-2 gap-1.5 mt-2.5">
        {uc.kpis.slice(0, 2).map((k, i) => {
          const isUp = k.direction === "up";
          return (
            <div key={i} className="bg-slate-50 rounded-md px-1.5 py-1 border border-slate-100">
              <div className="mono text-[8px] text-slate-500 truncate uppercase font-semibold">{k.label}</div>
              <div
                className="mono text-[11px] font-bold flex items-center gap-0.5"
                style={{ color: isUp ? "#16a34a" : "#dc2626" }}
              >
                {isUp ? <ArrowUpRight className="size-2.5" /> : <ArrowDownRight className="size-2.5" />}
                {k.delta}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between mt-2.5 pt-2.5 border-t border-slate-100">
        <span className="text-[10px] text-slate-500 truncate">{uc.subIndustry}</span>
        <ChevronRight className="size-3.5 text-slate-400 group-hover:text-[#004c97] group-hover:translate-x-0.5 transition" />
      </div>
    </button>
  );
}
