import type { Metadata } from "next";
import { Montserrat, Open_Sans } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const montserrat = Montserrat({
  variable: "--font-montserrat",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

const openSans = Open_Sans({
  variable: "--font-opensans",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "KefiTech CIP — Contextual Intelligence Platform",
  description:
    "Industry use-case explorer for the KefiTech Contextual Intelligence Platform — a graph neural network powered service for Banking, Pharma, Finance, Insurance and Manufacturing.",
  keywords: [
    "Contextual Intelligence",
    "Graph Neural Networks",
    "Banking",
    "Pharma",
    "Finance",
    "Insurance",
    "Manufacturing",
    "KefiTech",
    "Kefi Tech",
  ],
  authors: [{ name: "Kefi Tech" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "KefiTech CIP — Contextual Intelligence Platform",
    description:
      "Industry use-case explorer for graph neural network powered contextual intelligence.",
    siteName: "KefiTech CIP",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "KefiTech CIP",
    description:
      "Industry use-case explorer for graph neural network powered contextual intelligence.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="light" suppressHydrationWarning>
      <body
        className={`${montserrat.variable} ${openSans.variable} antialiased bg-background text-foreground font-[var(--font-opensans)]`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
