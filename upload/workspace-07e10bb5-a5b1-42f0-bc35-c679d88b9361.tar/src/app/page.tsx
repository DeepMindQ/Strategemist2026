"use client";

import { useMemo, useState } from "react";
import { INDUSTRIES, UseCase, getUseCase } from "@/lib/usecase-data";
import { Header } from "@/components/palantir/header";
import { Hero } from "@/components/palantir/hero";
import { Ticker } from "@/components/palantir/ticker";
import { IndustrySelector } from "@/components/palantir/industry-selector";
import { IndustryDashboard } from "@/components/palantir/industry-dashboard";
import { UseCaseDetail } from "@/components/palantir/use-case-detail";
import { CapabilitiesMatrix } from "@/components/palantir/capabilities-matrix";
import { CrossIndustryMatrix } from "@/components/palantir/cross-industry-matrix";
import { Architecture } from "@/components/palantir/architecture";
import { Footer } from "@/components/palantir/footer";
import { SearchPalette, useSearchShortcut } from "@/components/palantir/search-palette";
import { Panel } from "@/components/palantir/panel";

export default function Home() {
  const [activeIndustry, setActiveIndustry] = useState<string>(INDUSTRIES[0].id);
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeUseCase, setActiveUseCase] = useState<UseCase | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  useSearchShortcut(() => setSearchOpen(true));

  const industry = useMemo(
    () => INDUSTRIES.find((i) => i.id === activeIndustry) ?? INDUSTRIES[0],
    [activeIndustry]
  );

  // when search palette selects a use case, also switch to its industry
  const handleSelectUseCase = (id: string) => {
    const uc = getUseCase(id);
    if (!uc) return;
    const ind = INDUSTRIES.find((i) => i.name === uc.industry);
    if (ind) setActiveIndustry(ind.id);
    setActiveUseCase(uc);
    setDetailOpen(true);
    // ensure use-case section is visible
    requestAnimationFrame(() => {
      document.getElementById("use-cases")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  const handleSelectIndustry = (id: string) => {
    setActiveIndustry(id);
    requestAnimationFrame(() => {
      document.getElementById("industries")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  const handleOpenUseCase = (uc: UseCase) => {
    setActiveUseCase(uc);
    setDetailOpen(true);
  };

  const handleJumpTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header onOpenSearch={() => setSearchOpen(true)} onJumpTo={handleJumpTo} />

      <main className="flex-1">
        <Hero onJumpTo={handleJumpTo} onOpenSearch={() => setSearchOpen(true)} />

        <Ticker />

        {/* Industries section */}
        <section id="industries" className="max-w-[1600px] mx-auto px-4 lg:px-6 py-8 lg:py-12 space-y-4">
          <div className="flex items-end justify-between flex-wrap gap-2">
            <div>
              <div className="mono text-[10px] tracking-[0.3em] text-[#004c97] mb-1 font-semibold">
                INDUSTRIES // SELECT DOMAIN
              </div>
              <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
                Choose an industry. Load its contextual intelligence.
              </h2>
              <p className="text-sm text-slate-600 mt-1 max-w-2xl">
                Each industry opens a dedicated explorer: live KPI band,
                sub-domain coverage, indexed use cases and a capability
                utilisation panel.
              </p>
            </div>
            <div className="mono text-[10px] text-slate-500 font-semibold">
              {INDUSTRIES.length} INDUSTRIES · {INDUSTRIES.reduce((a, i) => a + i.subIndustries.length, 0)} SUB-DOMAINS
            </div>
          </div>

          <IndustrySelector active={activeIndustry} onChange={setActiveIndustry} />

          {/* Active industry dashboard */}
          <IndustryDashboard
            key={industry.id}
            industry={industry}
            onOpenUseCase={handleOpenUseCase}
          />
        </section>

        {/* Cross-industry matrix */}
        <section className="max-w-[1600px] mx-auto px-4 lg:px-6 pb-8 lg:pb-12">
          <CrossIndustryMatrix onPick={handleSelectIndustry} />
        </section>

        {/* Capabilities */}
        <section className="max-w-[1600px] mx-auto px-4 lg:px-6 pb-8 lg:pb-12">
          <CapabilitiesMatrix />
        </section>

        {/* Architecture */}
        <section className="max-w-[1600px] mx-auto px-4 lg:px-6 pb-8 lg:pb-12">
          <Architecture />
        </section>

        {/* CTA strip */}
        <section className="max-w-[1600px] mx-auto px-4 lg:px-6 pb-8 lg:pb-12">
          <Panel accent="#004c97" glow scan>
            <div className="grid lg:grid-cols-12 gap-5 items-center">
              <div className="lg:col-span-8">
                <div className="mono text-[10px] tracking-[0.3em] text-[#ff6c0e] mb-1 font-semibold">
                  ENGAGE // NEXT STEP
                </div>
                <h3 className="font-display text-xl lg:text-2xl font-bold tracking-tight text-slate-900">
                  Press <kbd className="mono text-xs px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-700 font-semibold">⌘K</kbd>{" "}
                  to search the index, or request a working session on your industry.
                </h3>
                <p className="text-sm text-slate-600 mt-2 max-w-2xl">
                  A 90-minute briefing maps your data estate, identifies three
                  high-leverage use cases for your context, and delivers a KefiTech CIP
                  deployment plan with target KPIs.
                </p>
              </div>
              <div className="lg:col-span-4 flex flex-col gap-2">
                <button
                  onClick={() => setSearchOpen(true)}
                  className="w-full bg-[#004c97] text-white py-2.5 rounded-md font-bold text-sm hover:bg-[#003a73] transition shadow-sm hover:shadow-md"
                >
                  Search use cases →
                </button>
                <button
                  onClick={() => handleJumpTo("industries")}
                  className="w-full border border-[#ff6c0e] text-[#ff6c0e] py-2.5 rounded-md font-bold text-sm hover:bg-[#ff6c0e] hover:text-white transition"
                >
                  Browse industries
                </button>
              </div>
            </div>
          </Panel>
        </section>
      </main>

      <Footer />

      <SearchPalette
        open={searchOpen}
        onOpenChange={setSearchOpen}
        onSelectUseCase={handleSelectUseCase}
        onSelectIndustry={handleSelectIndustry}
      />

      <UseCaseDetail
        useCase={activeUseCase}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        accent={
          INDUSTRIES.find((i) => i.name === activeUseCase?.industry)?.accent ?? "#004c97"
        }
      />
    </div>
  );
}
